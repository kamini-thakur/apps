<?php

require_once 'header.php';
require 'keys.php';
require 'shopify.php';
require 'database_config.php';

if(!$_SESSION['shop'])
{
   header('Location: login.php');
}

$_DOMAIN=$_SESSION['shop'];
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
$_SHOP = ($sc->call('GET', '/admin/shop.json?fields=email,myshopify_domain,name,country'));
$_SHOP['platform'] = 'Shopify';
$_SHOP['token'] = $_SESSION['token'];

// echo "<pre>";
// print_r($_SHOP);
// echo "</pre>";  

/* Send vendor details to MVP */

//$fh =fopen('Updatevendor.txt', 'w')  or fwrite($fh,"Utyftyftf");
$vendorDetails = httpPost('https://app.fashioncircle.de/vendors/add',$_SHOP);

// echo 'response';
print_r($vendorDetails);

// echo $_SHOP['token'];

$baseURL = 'https://shopify.fashioncircle.de';

//////////// Create app uninstallation webhook as well as check it ////////////
$url ='/admin/webhooks.json';

$uninstallArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/vendorApp/webhooks/uninstall.php');
      $uninstallMeta=array
      (
                    "webhook"=>array 
                    (
                     "topic"=> "app/uninstalled",
                     "address"=> $baseURL."/vendorApp/webhooks/uninstall.php",
                     "format"=>"json"
                    )
      );
    

      if (empty($uninstallArray))
      {     
          $sc->call('POST', $url,$uninstallMeta);
      }

//////////// Create product deletion webhook ////////////

$prodArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/vendorApp/webhooks/productDelete.php');
      $prodMeta=array
                (
                    "webhook"=>array 
                    (
                     "topic"=> "products/delete",
                     "address"=> $baseURL."/vendorApp/webhooks/productDelete.php",
                     "format"=>"json"
                            )
      );
    

        if (empty($prodArray)) {
           
            $sc->call('POST', $url,$prodMeta);
        }       

////////////////// Order webhook /////////////////

// $array=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/vendorApp/webhooks/order.php');
//       $meta=array
//       (
//             "webhook"=>array 
//                     (
//                      "topic"=> "orders/create",
//                      "address"=> $baseURL."/vendorApp/webhooks/order.php",
//                      "format"=>"json"
//                     )
//       );
    

//       if (empty($array)) {
           
//           $sc->call('POST', $url,$meta);
//       }       

/////////////////// Get shop currency /////////////////////////

$shopCurrency = ($sc->call('GET', '/admin/shop.json?fields=currency,money_format'));
$toCurrency=$shopCurrency['currency'];
$money_format= $shopCurrency['money_format'];
$symbol = explode("{{", $money_format);

?>

<body id="shopifyAPP">
<div class="loading-dots" id="loading-dots">
<center>
<div class="loaderDots">Loading...</div>
</center>
</div>
<?php

$i = 0;

/*=============Get all shop products details==============*/
$getProducts= $sc->call('GET','/admin/products.json');

// echo "<pre>";
// print_r($getProducts);
// echo "</pre>";  

echo '<div class="ProductDiv">';
echo '<ul>';
foreach ($getProducts as $key => $value) {

  $dropshipPrice = $sc->call('GET','/admin/products/'.$value["variants"][0]['product_id'].'/metafields.json?namespace=FCDropPrice');
  if (!empty($dropshipPrice)) {
    
    $key = array_search('FCDropPrice', array_column($dropshipPrice, 'namespace'));
    $dropshippingPrice=$dropshipPrice[$key]['value'];
  }
  else
  {
    $dropshippingPrice=null;
  }

  $wholesalePrice = $sc->call('GET','/admin/products/'.$value["variants"][0]['product_id'].'/metafields.json?namespace=FCWholesalePrice');
  if (!empty($wholesalePrice)) {
    $key = array_search('FCSellingPrice', array_column($wholesalePrice, 'namespace'));
    $wholesaleProdPrice=$wholesalePrice[$key]['value'];
  }
  else
  {
    $wholesaleProdPrice='';
  }

  $IsFashioncircleProd = $sc->call('GET','/admin/products/'.$value["variants"][0]['product_id'].'/metafields.json?namespace=FashionCircle');

if(!empty($IsFashioncircleProd))
{
  echo '<li class="addedProduct">';
}
else
{
  echo '<li class="">';
}
echo '<form id="form-'.$value["variants"][0]['product_id'].'">';

// $total_price = ($value->dropshipping_price+($value->dropshipping_price)*($value->commission/100));
// $getprice=($total_price)*($rate);

echo '<input type="hidden" name="title" value="'.$value["title"].'">';
echo '<input type="hidden" name="price" data-total-price="'.$total_price.'" value="'.$value["variants"][0]["price"].'">';
// echo '<input type="hidden" name="selling_price" data-total-price="'.$total_price.'" value="'.$value["variants"][0]["compare_at_price"].'">';

////////////// Show multiple images of products ///////////////
$img=1;
foreach ($value['images'] as $k => $v)
{
  echo '<input type="hidden" name="image[]" value="'.$v['src'].'">';
  $img++;
}

echo '<input type="hidden" name="description" value="'.$value['body_html'].'">';
echo '<input type="hidden" name="sku" value="'.$value["variants"][0]["sku"].'">';

// echo '<input type="hidden" name="user_id" value="'.$value->user_id.'">';
echo '<input type="hidden" id="shopify_product_id'.'-'.$value["variants"][0]['product_id'].'" name="shopify_product_id" value="'.$value["variants"][0]['product_id'].'">';
echo '<input type="hidden" name="quantity" value="'.$value["variants"][0]["inventory_quantity"].'">';
echo '<input type="hidden" name="vendorName" value="'.$value["vendor"].'">';

echo '<div class="ProductImg"><img src="'.$value['image']['src'].'" /></div>';
echo '<div class="ProductDesc">';
echo '<span class="ProductTitle">'.$value["title"].'</span>';
// echo '<span class="ProductVendor">'.$value["vendor"].'</span>';
echo '<span class="ProductPrice" data-price-euro="'.$value["variants"][0]['price'].'">'.$symbol[0].$value["variants"][0]['price'].'</span>';

echo '<div class="dropshippingPrice">';
// echo '<div class="dropshipPrice"></div>';
echo '<div class="DropshipCheckbox"><input type="checkbox" name="enable_dropship" value="yes" checked disabled><h5>Dropshipping</h5><input class="dropshipping_price_'.$i.'" data-dropship-price="dropshipping_price_'.$i.'" data-price-euro="'.$value["variants"][0]['price'].'" name="dropshipping_price" type="text" placeholder="Enter price" value="'.$dropshippingPrice.'"></div></div>';

echo '<div class="dropshippingPrice">';
// echo '<div class="dropshipPrice"></div>';
echo '<div class="DropshipCheckbox"><input type="checkbox" name="enable_wholesale" value="yes" disabled><h5>Wholesale</h5><input class="wholesale_price_'.$i.'" data-wholesale-price="wholesale_price_'.$i.'" data-price-euro="'.$value["variants"][0]['price'].'" name="wholesale_price" type="text" placeholder="Enter price" value="'.$wholesaleProdPrice.'"></div></div>';

echo '<div class="returnBack">Returns: <input type="checkbox" name="enable_label" value="yes" disabled checked> to label <input type="checkbox" name="enable_retailer" value="yes" disabled> to retailer</div>';

echo "</div>";
$a = 0;
$r =1;
if(!empty($IsFashioncircleProd))
{
  echo '<div class="OnHover"><input type="submit" value="Remove from Fashion Circle" id="button-'.$value["variants"][0]['product_id'].'" onclick="ProductEvent(event,'.$value["variants"][0]['product_id'].','.$r.','.$i.')" /></div>';
}
else
{
 echo '<div class="OnHover"><input type="submit" value="Add to Fashion Circle" id="button-'.$value["variants"][0]['product_id'].'" onclick="ProductEvent(event,'.$value["variants"][0]['product_id'].','.$a.','.$i.')" /></div>';
}
echo '<div class="available-qty"> Quantity Available: <span>'.$value["variants"][0]["inventory_quantity"].'</span></div>';
echo '</form>';
echo '</li>';
++$i;
 
}

echo '</ul>';
echo '</div>';


function httpPost($url, $data)
{
    $responseArray = array();
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
      'Api-Key: pbkdf2_sha256$29000$p7lpJChcK4Lo$IHMul9j5lcPNJP4f/W1nXZknVi2N+GJIR1tZCo5C7uM='
       ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $res = json_decode($response);
    return $res;
}

?>
</body>
</html>


 <script type="text/javascript">
    ShopifyApp.init({
      apiKey: '<?php echo $api_key; ?>',
      shopOrigin:"<?php echo $shopURL; ?>",

      debug: true
    });
    </script>
<script type="text/javascript">
  ShopifyApp.ready(function(){
    ShopifyApp.Bar.initialize({
      
      title: 'Fashion Circle',
      
          callback: function(){ 
            ShopifyApp.Bar.loadingOff();
            
          }
    });
  });
  </script>

<script type="text/javascript">

function ProductEvent(e,i,type,loop)
{
    e.preventDefault();
    if(!type)
    { 
      var dropshipping_price= $('.dropshipping_price_'+loop).val();
      var wholesale_price= $('.wholesale_price_'+loop).val();
      //alert(dropshipping_price);
      if(dropshipping_price == '' || dropshipping_price == undefined)
      {
          $('.dropshipping_price_'+loop).css('border','1px solid red');
          return false;
      }
      $('.dropshipping_price_'+loop).css('border','1px solid #ccc');
      if(wholesale_price == '' || wholesale_price == undefined)
      {
          $('.wholesale_price_'+loop).css('border','1px solid red');
          return false;
      }
    }
  
    $('.dropshipping_price_'+loop).css('border','1px solid #ccc');
    $('.wholesale_price_'+loop).css('border','1px solid #ccc');

    $('#loading-dots').show();
    var xhr = new XMLHttpRequest();
    if(!type)
    {
      var url = 'AddToMVP.php';
      var d = $('form#form-'+i).serialize();
    }
    else
    {
      var url = 'RemoveFromMVP.php';
      var d = 'shopify_product_id='+$('#shopify_product_id-'+i).val();
    }
    
    xhr.open('POST', url, true);
   
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(d);
    xhr.onreadystatechange = function() {
    //If the request completed
   
    if (xhr.readyState == 4)
	  {         //statusDisplay.innerHTML = '';
       if(xhr.status == 200) {  
              var d= (xhr.responseText);

              //alert('value of d ='+d);
              obj = JSON.parse(d);
              //alert('value of obj ='+obj);
              if(obj.response === 'Success')
               {               
                  var t = parseInt(obj.product_id);
                  var buttonId= 'button-'+t;
                  
                  var i ='shopify_product_id-'+t;
                  
                  // var o = e.target.getAttribute('id');
                  // console.log(o);
                  // alert('type'+type);
                  if(parseInt(type))
                   {
                    // alert('turn into add');
                    // alert(buttonId);
                      // document.getElementById(i).value= '';
                      document.getElementById(buttonId).parentElement.innerHTML = '<input type="submit" value="Add to Fashion Circle" id='+buttonId+' onclick="ProductEvent(event,'+t+',0,'+loop+')" />';   
                      $('#'+buttonId).parent().closest('li').removeClass('addedProduct');   
                   }
                   else
                   {
                     //document.getElementById(i).value= t;
                     document.getElementById(buttonId).parentElement.innerHTML = '<input type="submit" value="Remove from Fashion Circle" id='+buttonId+' onclick="ProductEvent(event,'+t+',1,'+loop+')" />';
                     // $('.dropshipping_price_'+loop).attr('added_dropshipping_price',dropshipping_price);
                     // $('.wholesale_price_'+loop).attr('added_wholesale_price',wholesale_price);
                     // $(saveDropship).val(dropshipping_price);
                     // $(saveWolesale).val(wholesale_price);

                     $('#'+buttonId).parent().closest('li').addClass('addedProduct');
                   }

                  $('#loading-dots').hide();                         
               }

        }
             
    }
        $('#loading-dots').hide(); 
       
    } // Onreadystate function closed

    // $('form#form-'+i)[0].reset();
}

</script>

