<?php

$api_key = "5eb9b56c7420f2dc0068621f8235ef76";
$secret = "5a0a234fe77e74095b89da6454ac5f00";

$postUrl = 'https://app.fashioncircle.de';

?>