<?php


require_once '../shopify.php';
require_once '../keys.php';
require_once '../database_config.php';

/*  getting the domain from which request is made      */

$data = file_get_contents('php://input');
$fh=fopen('Uninstall.txt', 'w');

fwrite($fh,$data);
$Array    =json_decode($data);

$_DOMAIN  =$_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
fwrite($fh, $_DOMAIN);

try
{

		if(!empty($Array))
		{
            $array['website']            =  $_DOMAIN;
			httpPost('https://app.fashioncircle.de/vendors/uninstall_vendor',$array);
		}

		// $deleteRecord="DELETE from merchant_mvp_token where shopDomain='$_DOMAIN' ";
		// $executeDelete=mysqli_query($newCon,$deleteRecord);	
		// if($executeDelete)
		// {
		// 	$response = 'True';
		// }
		// else
		// {
		// 	$response = 'False';
		// }
		// fwrite($fh, $response);
		// mysqli_close($newCon);	

        // MVP needs to trigger the product deletion webhook 

}
catch (ShopifyApiException $e)
    {
		
        //fwrite($fh, $e->getMethod());// -> http method (GET, POST, PUT, DELETE)
        fwrite($fh,$e->getPath());// -> path of failing request
        fwrite($fh,$e->getResponseHeaders());// -> actually response headers from failing request
        fwrite($fh,$e->getResponse());// -> curl response object
        fwrite($fh,$e->getParams());// -> optional data that may have been passed that caused the failure
		
    }

function httpPost($url, $data)
{
	global $fh;
	fwrite($fh, $data);
    $curl = curl_init($url);
    curl_setopt ($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Api-Key: pbkdf2_sha256$29000$p7lpJChcK4Lo$IHMul9j5lcPNJP4f/W1nXZknVi2N+GJIR1tZCo5C7uM='
    ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $res = json_decode($response);
    fwrite($fh, $res);

    fwrite($fh, 'new response code');
    $res = json_decode($response,true);
    fwrite($fh, print_r($res,true));
    fwrite($fh, 'respones array');

    if(isset($res['success']))
    {
	 $responseArray['response'] = 'Success';
    }
    else
    {
     $responseArray['response'] = 'Failure';
    }
    fwrite($fh, json_encode($responseArray));
    
}
?>

