<?php

require_once '../header.php';
require '../keys.php';
require '../shopify.php';
require '../database_config.php';

$data     =(file_get_contents('php://input'));
$fh       =fopen('orderData.txt', 'w')  or die("Utyftyftf");
var_dump($fh);
fwrite($fh, $data);
fwrite($fh, '$_DOMAIN');

?>
