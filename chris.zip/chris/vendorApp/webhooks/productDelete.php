<?php

/* Webhook fires when we delete product from shopify store directly */

require '../keys.php';
require '../database_config.php';

$data     =(file_get_contents('php://input'));
$fh       =fopen('prodDelete.txt', 'w')  or die("Utyftyftf");
//var_dump($fh);
fwrite($fh, $data); 

$Array    =json_decode($data);
//$tempVar  = var_export($Array, true);
$productId = $Array->id;

fwrite($fh, $productId);

/* GET DOMAIN FROM HEDAERS  */
$_HEADERS = apache_request_headers();
$_DOMAIN  =$_HEADERS['X-Shopify-Shop-Domain'];

fwrite($fh, '$_DOMAIN');

fwrite($fh, $_DOMAIN);

try
        {
        

        if (!empty($productId)) {
                 $array['platform_pro_id'] = (int)$productId;
                 $array['website']            =  $_DOMAIN;
                 httpPost('https://app.fashioncircle.de/vendors/delete_product',$array);
       }
       

}
catch (ShopifyApiException $e)
    {
		
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
		
    }


function httpPost($url, $data)
{
    global $fh, $sc;
    $responseArray = array();
    $curl = curl_init($url);
    curl_setopt ($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Api-Key: pbkdf2_sha256$29000$p7lpJChcK4Lo$IHMul9j5lcPNJP4f/W1nXZknVi2N+GJIR1tZCo5C7uM='
    ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    //$res = json_decode($response);

    $res = json_decode($response,true);
    fwrite($fh, print_r($res,true));
    fwrite($fh, 'respones array');

    if(isset($res->success))
    {
        $responseArray['response'] = 'Success';
        $responseArray['product_id']  = $data['platform_pro_id'];

        // $getProdMetafields = $sc->call('GET','/admin/products/'.$data['platform_pro_id'].'/metafields.json?namespaces=FashionCircle,FCDropPrice,FCSellingPrice');
        // if (!empty($getProdMetafields)) {
        //     foreach ($getProdMetafields as $key => $val) {
        //         $metafieldId = $val['id'];
        //         $sc->call('DELETE','/admin/products/'.$data['platform_pro_id'].'/metafields/'.$metafieldId.'.json'); 
        //     }
        // }
    }
    else
    {
       $responseArray['response'] = 'Failure';
    }
    echo  json_encode($responseArray);
    
}



?>