<?php
// error_reporting(E_ALL);
// ini_set("display_errors", 1);

require '../shopify.php';
require '../keys.php';

$data     =file_get_contents('php://input');

$fh       =fopen('deleteVendorProd.txt', 'w')  or fwrite($fh,"Utyftyftf");

fwrite($fh, $data);

$array = json_decode($data);

///////////// Hide products from shopify store ///////////////

foreach($array as $key=>$val)
{
	fwrite($fh,'going');

	$token=$val->token;
	//fwrite($fh,'json token'.$token);

	$shopify_domain = $val->shopify_domain;
	//fwrite($fh,'json domain'.$shopify_domain);

	$PlatformProductId = (string)$val->PlatformProductId;
	//fwrite($fh,'json id'.$PlatformProductId);

	fwrite($fh,'api key'.$api_key);
	//fwrite($fh,'secret'.$secret);

	$sc = new ShopifyClient($shopify_domain, $token, $api_key, $secret);

	$getProdMetafields = $sc->call('GET','/admin/products/'.$PlatformProductId.'/metafields.json?namespaces=FashionCircle,FCDropPrice,FCSellingPrice');
    if (!empty($getProdMetafields)) {
            foreach ($getProdMetafields as $key => $val) {
                $metafieldId = $val['id'];
                $sc->call('DELETE','/admin/products/'.$PlatformProductId.'/metafields/'.$metafieldId.'.json'); 
            }
    }

	fwrite($fh,'working'); 

	unset($sc);
}

?>