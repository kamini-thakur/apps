<?php
session_start();
require 'keys.php';
require 'shopify.php';
$_DOMAIN = $_SESSION['shop'];
$Array = array();
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
$productId = $_POST['shopify_product_id'];

$fh       =fopen('removeMvp.txt', 'w')  or die("Utyftyftf");
fwrite($fh, $productId);

try
{
       if (isset($productId)) {
         
                 $array['platform_pro_id'] = (int)$productId;
                 $array['website']            =  $_SESSION['shop'];
                 httpPost('https://app.fashioncircle.de/vendors/delete_product',$array);
       }
}
catch (ShopifyApiException $e)
    {
		
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
		
    }


function httpPost($url, $data)
{
    global $fh, $sc;
    $responseArray = array();
    $curl = curl_init($url);
    curl_setopt ($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Api-Key: pbkdf2_sha256$29000$p7lpJChcK4Lo$IHMul9j5lcPNJP4f/W1nXZknVi2N+GJIR1tZCo5C7uM='
    ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    //$res = json_decode($response);

    $res = json_decode($response,true);
    fwrite($fh, print_r($res,true));
    fwrite($fh, 'respones array');

    if(isset($res['success']))
    {
      	$responseArray['response'] = 'Success';
      	$responseArray['product_id']  = $data['platform_pro_id'];

        $getProdMetafields = $sc->call('GET','/admin/products/'.$data['platform_pro_id'].'/metafields.json?namespaces=FashionCircle,FCDropPrice,FCSellingPrice');
        if (!empty($getProdMetafields)) {
            foreach ($getProdMetafields as $key => $val) {
                $metafieldId = $val['id'];
                $sc->call('DELETE','/admin/products/'.$data['platform_pro_id'].'/metafields/'.$metafieldId.'.json'); 
            }
        }
    }
    else
    {
       $responseArray['response'] = 'Failure';
    }
    echo  json_encode($responseArray);
    
}

?>