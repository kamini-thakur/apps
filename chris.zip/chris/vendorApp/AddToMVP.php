<?php
session_start();
require 'keys.php';
require 'shopify.php';
require 'database_config.php';

$_DOMAIN = $_SESSION['shop'];
$Array = array();
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);

// print_r($_POST['image']);
// $images=implode("','", $_POST['image']);
// $images = "'".$images."'";

$images=implode(",", $_POST['image']);
$images = $images;

$Array = array
(
    'product_id' => (string)$_POST['shopify_product_id'],
    'title'=>$_POST['title'],
    'category'=> 'clothing',
    'platform'=> 'shopify',
    'myshopify_domain'=> $_SESSION['shop'],
    'description'=>$_POST['description'],
    "quantity" => $_POST['quantity'],
    'selling_price'=> $_POST['price'],
    'dropshipping_price'=> $_POST['dropshipping_price'],
    'wholesale_price'=> $_POST['wholesale_price'],
    'sku'=> $_POST['sku'],
    'image'=> $images
);


mail('kamini_thakur@esferasoft.com', 'Adding product to MVP', json_decode($Array));

$fh       =fopen('mvp.txt', 'w')  or die("Utyftyftf");
fwrite($fh, print_r($Array,true));

// echo '<pre>';
// print_r($Array);
// echo '</pre>';

try
{
        if(!empty($Array['product_id']))
        {
           $vendorName = $_POST['vendorName'];
           httpPost('https://app.fashioncircle.de/vendors/add_product',$Array,$vendorName,$sc);
        }

}
catch (ShopifyApiException $e)
    {
		
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
		
    }


function httpPost($url, $data,$vendorName,$sc)
{
    global $fh;
    $responseArray = array();
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
      'Api-Key: pbkdf2_sha256$29000$p7lpJChcK4Lo$IHMul9j5lcPNJP4f/W1nXZknVi2N+GJIR1tZCo5C7uM='
       ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $res = json_decode($response,true);
    fwrite($fh, print_r($res,true));
    fwrite($fh, 'respones array');
    if(isset($res['success']))
    {
	
      $responseArray['product_id'] = $data['product_id'];
	    $responseArray['response'] = 'Success';

      $meta = array( "product" =>array("metafields"=> array(
          '0' => array(
            "key"=> "AddedInMVP",
            "value"=> "yes",
            "value_type"=> "string",
            "namespace"=> "FashionCircle"
          ),
          '1' => array(
            "key"=> "FCProductPrice",
            "value"=> $data['selling_price'],
            "value_type"=> "string",
            "namespace"=> "FCSellingPrice"
          ),
          '2' => array(
            "key"=> "FCDropShipPrice",
            "value"=> $data['dropshipping_price'],
            "value_type"=> "string",
            "namespace"=> "FCDropPrice"
          ),
          '3' => array(
            "key"=> "FCWholePrice",
            "value"=> $data['wholesale_price'],
            "value_type"=> "string",
            "namespace"=> "FCWholesalePrice"
          )
        )
      )
      );

      $AddMetafield=$sc->call('PUT','/admin/products/'.$data['product_id'].'.json',$meta);
      
    }
      
    else
    {
        $responseArray['response'] = 'Failure';
    }
    fwrite($fh,print_r($responseArray,true));
    echo  json_encode($responseArray);
}



?>
