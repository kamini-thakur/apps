<?php

echo 'hi'; 



$Array = 'title=Test%20Watch&price=4000.00&image=https%3A%2F%2Fcdn.shopify.com%2Fs%2Ffiles%2F1%2F2063%2F5177%2Fproducts%2Fproduct-image-116236004_grande_74d005af-c6f8-4aa8-9862-9e12a6ec68bb.jpg%3Fv%3D1497682075&image=https%3A%2F%2Fcdn.shopify.com%2Fs%2Ffiles%2F1%2F2063%2F5177%2Fproducts%2Fcol2.jpg%3Fv%3D1497682109&image=https%3A%2F%2Fcdn.shopify.com%2Fs%2Ffiles%2F1%2F2063%2F5177%2Fproducts%2Fring-1.jpg%3Fv%3D1497682134&description=Its%20test%20product%20on%20vendor%20plugin%20shop%20added%20from%20shop&sku=QWE45&vendor=FashionCircleChris&shopify_product_id=9780416914&quantity=100&platform_product_id=9780416914';

//mail('kamini_thakur@esferasoft.com', 'Adding product to MVP', $Array);

// foreach ($_POST['image'] as $key => $value) {
//     $src[$key] => $value;
// }


echo '<pre>';
print_r($Array);
echo '</pre>';

$Array = array
(
    'product_id' => $_POST['shopify_product_id'],
    'title'=>$_POST['title'],
    'vendor'=>$_POST['vendor'],
    'description'=>$_POST['description'],
    "quantity" => $_POST['quantity'],
    "price"=> $_POST['price'],
    "sku"=> $_POST['sku']
);

echo '<pre>';
print_r($Array);
echo '</pre>';

?>