
<?php

header('charset=utf-8');

session_start();
require 'keys.php';
require 'shopify.php';
require 'database_config.php';

$_DOMAIN = $_SESSION['shop'];
$Array = array();
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);

$fh       =fopen('AddToShopify.txt', 'w')  or fwrite($fh,"Utyftyftf");

/// Getting products multiple images ////
$images = array();
for ($i=0; $i < count($_POST['image']); $i++) {
        $image = array(
                    'src'=> $_POST['image'][$i]
        );
        $images[] = $image;
}

$Array['product'] = array
(
    'title'=>$_POST['title'],
    'vendor'=>"Fashioncircle-".$_POST['vendor'],
    'body_html'=>$_POST['description'],
    "product_type"=> "",
    "tags"=> "Fashioncircle-".$_POST['vendor'],

    'images'=> $images,
    "metafields"=> array(
      '0' => array(
        "key"=> "fashionCircle",
        "value"=> "Fashioncircle-".$_POST['vendor'],
        "value_type"=> "string",
        "namespace"=> "fashionCircleProduct"
      ),
      '1' => array(
        "key"=> "fashionCirclePrice",
        "value"=> $_POST['price'],
        "value_type"=> "string",
        "namespace"=> "FCProdPrice"
      )
    ),
    'variants' =>array(
     '0' => array(
         "option1"=> "Default Title",
        "inventory_policy" => "deny",
        "inventory_management" => "shopify",
        "inventory_quantity" => $_POST['quantity'],
        "price"=> $_POST['price'],
        "sku"=> $_POST['sku']
        )
     )
 );
// echo '<pre>';
// print_r($Array);
// echo '</pre>';

fwrite($fh, print_r($Array,true));

mail('kamini_thakur@esferasoft.com', 'Adding product to MVP',$_POST['title'] );

try
{
        $request = $sc->call('POST','/admin/products.json',$Array);

        if (isset($request['id'])) {

               $array['vendor_id']          =$_POST['user_id'];
                $array['product_id']        = $_POST['mvp_product_id'];
                $array['domain']            =  $_SESSION['shop'];
                $array['platform']          ='Shopify';
                $array['isAdded']           = true;
                $array['PlatformProductId'] =$request['id'];	
                $currentProdID = $request['id'];

          // $shopDomain = $_SESSION['shop'];
          // $sql="SELECT * from merchant_mvp_token where shopDomain='$shopDomain' ";
          // $qex=mysqli_query($newCon,$sql);
          // $num_rows=mysqli_num_rows($qex);
  
          // if($num_rows > 0)
          // {
          //   $getShopProd="SELECT shopProducts from merchant_mvp_token where shopDomain='$shopDomain' ";
          //   $qex1=mysqli_query($newCon,$getShopProd);
          //    $res =  mysqli_fetch_array($qex1);
          //    if(empty($res['shopProducts']))
          //    {
          //         $sql1="UPDATE merchant_mvp_token SET shopProducts= '$currentProdID' WHERE shopDomain='$shopDomain' ";
          //         $qex1=mysqli_query($newCon,$sql1);
          //    }
          //    else
          //    {
          //      $shopProducts = $res['shopProducts'].','.$currentProdID;
          //         $sql1="UPDATE merchant_mvp_token SET shopProducts= '$shopProducts' WHERE shopDomain='$shopDomain' ";
          //         $qex1=mysqli_query($newCon,$sql1);
          //    }
              
          // }


            httpPost('https://app.fashioncircle.de/merchants/products/add',$array,$currentProdID,$sc);
          
        }
       

}
catch (ShopifyApiException $e)
    {
		
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
		
    }


function httpPost($url, $data,$currentProdID,$sc)
{
  global $fh;
    $responseArray = array();
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Access-Token: '.$_SESSION['mvp_access_token']
    ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);

    $res = json_decode($response,true);
    fwrite($fh, $response);
    fwrite($fh, 'respones array');

    $res = json_decode($response);

    if(isset($res->Success))
      {
	
	$responseArray['id']=$data['PlatformProductId'];
	$responseArray['mvpId']=$data['product_id'];
	$responseArray['response'] = 'Success';
        
    }
      
    else
    {
        $responseArray['response'] = 'Failure';
        $delete = $sc->call('DELETE','/admin/products/'.$currentProdID.'.json');
        //deleteFromShopify($currentProdID);
    }
   echo  json_encode($responseArray);
}

// function deleteFromShopify($currentProdID)
// {
//     $delete = $sc->call('DELETE','/admin/products/'.$currentProdID.'.json');
// }

?>


בחר תאריך 


השאירו כתובת דוא״ל ונשלח לכם ידע מרתק

the notification product image border

קהילת החולמים
content here :
מעוניינים להצטרף לקהילת החולמים? השאירו מייל ונשלח לכם ידע מרתק למייל



השאירו כתובת דוא״ל ונשלח לכם ידע מרתק



=====================

setTimeout(function(){ alert("Hello"); }, 3000);


newsletter-success