<?php

mail('kamini_thakur@esferasoft.com', 'IPN response', 'hi');
require 'database_config.php';
require 'keys.php';

$transaction_data = file_get_contents('php://input');

//$transaction_data = 'mc_gross=3456.68&protection_eligibility=Eligible&address_status=confirmed&payer_id=FQHU9W75WC8M6&address_street=1+Main+St&payment_date=06%3A38%3A51+Jun+03%2C+2017+PDT&payment_status=Completed&charset=windows-1252&address_zip=95131&first_name=kamini&mc_fee=100.54&address_country_code=US&address_name=kamini+thaku%27s+Test+Store&notify_version=3.8&custom=4-fashioncirclechris.myshopify.com&payer_status=verified&business=sonukm786%40gmail.com&address_country=United+States&address_city=San+Jose&quantity=1&verify_sign=APclMDPdWaSSAOtbaJrWk-DEAcR8A0v3gTb6TlXqrRf4uEImDjmF7HAb&payer_email=kamini12%40esferasoft.com&txn_id=7ER34210NH9391310&payment_type=instant&payer_business_name=kamini+thaku%27s+Test+Store&last_name=thaku&address_state=CA&receiver_email=sonukm786%40gmail.com&payment_fee=100.54&receiver_id=CU2XD5DR2D44S&txn_type=web_accept&item_name=Pay+test&mc_currency=USD&item_number=&residence_country=US&test_ipn=1&transaction_subject=&payment_gross=3456.68&ipn_track_id=21dcad39d8957';

$fh       =fopen('ipn.txt', 'w')  or die("Utyftyftf");
fwrite($fh, 'transaction_data');
mail('kamini_thakur@esferasoft.com', 'IPN response', $transaction_data);
fwrite($fh, $transaction_data);

$post_array = explode('&', $transaction_data);

$dataFromPayPal = array();
foreach ($post_array as $keyval) {
    $keyval = explode ('=', $keyval);
    if (count($keyval) == 2)
        $dataFromPayPal[$keyval[0]] = urldecode($keyval[1]);
}
// echo '<pre>';
// print_r($dataFromPayPal);
// echo '</pre>';

 $paymentStatus  = $dataFromPayPal['payment_status'];
 $txn_id = $dataFromPayPal['txn_id'];
 $mc_gross = $dataFromPayPal['mc_gross'];
 $merchantEmail = $dataFromPayPal['payer_email'];
 $vendorEmail = $dataFromPayPal['receiver_email'];
 $payment_date = $dataFromPayPal['payment_date'];
 $vendorId = $dataFromPayPal['receiver_id'];
$custom = $dataFromPayPal['custom'];
$customArray=explode("=",$custom);
$paymentID = $customArray[0];
fwrite($fh, 'payment id='.$paymentID);
$shopDomain = $customArray[1];
fwrite($fh, 'shop url='.$shopDomain);

$vendorName = $dataFromPayPal['item_name'];
 //fwrite($fh, $shopDomain);

$vendor_name =str_replace('Pay ', '', $vendorName);


/////////////////// Insert all transaction details data into separate table /////////////////////

$insertTransaction="INSERT INTO transactionDetails(paymentID,shopDomain,vendorName,vendorEmail,amountPaid,merchantEmail,transactionId,paymentStatus,paymentCompletionDate) VALUES('".$paymentID."','".$shopDomain."','".$vendor_name."','".$vendorEmail."','".$mc_gross."','".$merchantEmail."','".$txn_id."','".$paymentStatus."','".$payment_date."')";
 
 $qex=mysqli_query($newCon,$insertTransaction);
 if (!$qex) {
        echo 'Transaction details not inserting';
    }
/////////////////////////////////

//////// Call to database to update the payment status / amount ////////////

$sql = "SELECT * from paymentDetails where shopDomain='$shopDomain' and vendorName = '$vendor_name' and paymentStatus != 'Completed' ";
$qex = mysqli_query($newCon,$sql);
$res = mysqli_fetch_array($qex);

if($res['amount'] > $mc_gross)
{
    $remainingAmount = $res['amount']-$mc_gross;
    $updateAmountLeft="UPDATE paymentDetails set amount='$remainingAmount' where vendorName = '$vendor_name' and shopDomain='$shopDomain' and paymentStatus != 'Completed' ";
    $qex=mysqli_query($newCon,$updateAmountLeft);

    if (!$qex) {
        echo 'Error has been occured during updating amount left';
    }
}
else
{
    $updateVendorPaymentStatus="UPDATE paymentDetails set paymentStatus='$paymentStatus', vendorId='$vendorId', transactionTrackingId='$txn_id',payment_completion_date='$payment_date',vendorEmail='$vendorEmail' where vendorName = '$vendor_name' and shopDomain='$shopDomain' and paymentStatus != 'Completed' ";
    $qex=mysqli_query($newCon,$updateVendorPaymentStatus);

    if (!$qex) {
        echo 'Error has been occured during updating status';
    }
    else
    {
        echo 'its working';
    }
}
//////////////////////////////////

$vendor = array();
$sql = "SELECT * from paymentDetails where shopDomain='$shopDomain' and vendorName = '$vendor_name' and paymentStatus = 'Completed' order by id desc limit 0,1 ";
$qex = mysqli_query($newCon,$sql);
$res = mysqli_fetch_array($qex);
$vendor['vendorName'] = $res['vendorName'];
$vendor['OrderID'] = $res['orderId'];

//////// Call to database to get the "Merchant MVP token" ////////////

echo $sql="SELECT * from merchant_mvp_token where shopDomain='$shopDomain' ";
$qex=mysqli_query($newCon,$sql);
$result = mysqli_fetch_array($qex);
$mvp_access_token = $result['mvp_access_token'];

///////// call to MVP if IPN payment status is completed ////////// 
if ($paymentStatus == 'Completed') {
    fwrite($fh, 'Call to API in MVP to send the email to vendor');
    $resPayment=paymentStatus($postUrl.'/orders/paid',$vendor);
    // echo '<pre>';
    // print_r($vendor);
    // echo '</pre>';
    //echo $resPayment;
}


function paymentStatus($url, $data)
{
  global $fh,$mvp_access_token;
  fwrite($fh, '<------+++++payment details+++++++------------');
  fwrite($fh, json_encode($data));
    $curl = curl_init($url);
    //curl_setopt($curl, CURLOPT_HEADER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Access-Token: '.$mvp_access_token
    ));
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    fwrite($fh, '<------+++++payment details response+++++++----------');
    //fwrite($fh, $response);

    curl_close($curl);
    $result = json_decode($response); 
    
    if(isset($result->success))
    {
      $responseArray['response'] = 'Success';
    }
    else
    {
     $responseArray['response'] = 'Failure';
    }
    fwrite($fh, json_encode($responseArray));
    return $response;
}

?>
<?php 

/*

$req = 'cmd=_notify-validate';
if(function_exists('get_magic_quotes_gpc')) {
    $get_magic_quotes_exists = true;
}
foreach ($dataFromPayPal as $key => $value) {
    if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
        $value = urlencode(stripslashes($value));
    } else {
        $value = urlencode($value);
    }
    $req = "&$key=$value";
}
echo 'hello';


$ch = curl_init('https://www.paypal.com/cgi-bin/webscr');
//use https://www.sandbox.paypal.com/cgi-bin/webscr in case you are testing this on a PayPal Sanbox environment
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
 
if( !($res = curl_exec($ch)) ) {
    curl_close($ch);
    exit;
}
curl_close($ch);


function paymentComplete() {
    //email the buyer that payment is complete and that products will be shipped soon. Enter details about the same in database.
    mail('kamini_thakur@esferasoft.com','payment completed','successfull');
}
 
function paymentIncomplete() {
    //email the buyer that payment is not complete
    mail('kamini_thakur@esferasoft.com','payment status','incomplete');
}
 
function paymentReversedOrRefunded() {
    //take note of the reversal or refund in your system/database and pause any shipment related to this order
}
 
function reversalCanceled() {
    //a payment that was reversed has been canceled. You can now ship the products for the said transaction
}
 
if (strcmp ($res, "INVALID") == 0) {
//invalid access to the IPN Script or something wrong with the transaction parameters
}
else if (strcmp ($res, "VERIFIED") == 0) {
    $payer_email = $_POST['payer_email'];
    $userEmailId = strtolower($payer_email);
    $paymentStatus = $_POST['payment_status'];
 
    $paypalTransactionID = $_POST['txn_id'];
    $totalPaymentReceived = $_POST['mc_gross'];
 
    if($paymentStatus == "Reversed" || $paymentStatus == "Refunded") {
        //call function to act for payment reversal or refund - you would probably want to stop shipment or request the buyer to return the product
        paymentReversedOrRefunded();
    } else if($paymentStatus == "Pending" || $paymentStatus == "Denied" || $paymentStatus == "Failed" || $paymentStatus == "Voided" || $paymentStatus == "Expired") {
        //pause shipment and inform buyer about the status of payment
        paymentIncomplete();
    } else if($paymentStatus == "Canceled_Reversal") {
        //reversal to the payment was canceled. You might now want to inform the buyer that the product is ready to be shipped as the payment as been received
        reversalCanceled();
    } else if($paymentStatus != "Completed") {
        //finally, if payment is not completed, then act accordingly
    }
 
    //if all checks passed, then move further
    $receiver_email = $_POST['receiver_email'];
    if($receiver_email != "<your_email_address_here>") {
        die("Invalid payment");
    }
 
    if($paymentStatus == "Completed" || $paymentStatus == "Processed") {
        $itemName = $_POST['item_name'];
        $item_number = $_POST['item_number'];
        $currency = $_POST['mc_currency'];
        paymentComplete();
    } else {
        die("Error! Payment not complete or processed");
    }
}
*/
?>