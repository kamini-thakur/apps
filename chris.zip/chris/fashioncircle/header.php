<?php
header('p3p: CP="ALL DSP COR PSAa PSDa OUR NOR ONL UNI COM NAV"');
ob_start();
session_start();
set_time_limit(0);
// ini_set("display_errors", 1);
ini_set('session.gc_maxlifetime', 36000);
session_set_cookie_params(36000);
// error_reporting(E_ALL);
?>
<html>
<head>
  <title>SHOPIFY APP</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
  <!-- <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> -->

  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script> -->

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

      <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">

      <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- <script type="text/javascript" src="//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js"></script> -->

  <!-- <script src="assets/js/owl.carousel.min.js"></script> -->
  <!-- <script src="assets/js/owl.carousel.js"></script> -->

  <link rel="stylesheet" href="assets/admin.css" />

  <link  href="http://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.css" rel="stylesheet">
  <script src="assets/js/fotorama.js"></script> 

 <!--  <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.css"/> -->
  
 <!--  <link rel="stylesheet" href="assets/owl.carousel.css" /> -->
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css" /> -->
  <!-- <script src="assets/js/money.js"></script>
 -->  <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
  
  <style>
    .notification-message {
 width:98%;
 margin:10px auto;
 background-color: #f2dede;
 border: 1px solid #ebccd1;
 color: #a94442;
 padding: 10px;
 font-size: 16px;
 border-radius: 4px;
 -webkit-border-radius: 4px;
 -ms-border-radius: 4px;
 -o-border-radius: 4px;
 -moz-border-radius: 4px;
}

  </style>
</head>
