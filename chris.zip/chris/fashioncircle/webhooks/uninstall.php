<?php


require_once '../shopify.php';
require_once '../keys.php';
require_once '../database_config.php';

/*      getting the domain from which request is made      */

$data = file_get_contents('php://input');
$fh=fopen('Uninstall.txt', 'w');

fwrite($fh,$data);
$Array    =json_decode($data);

$_DOMAIN  =$_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
fwrite($fh, $_DOMAIN);

/* GET MVP-ACCESS-TOKEN FROM DATABASE  */
$sql="SELECT * from merchant_mvp_token where shopDomain='$_DOMAIN' ";
$qex=mysqli_query($newCon,$sql);
$res = mysqli_fetch_array($qex);

$mvp_access_token = $res['mvp_access_token'];
fwrite($fh,$mvp_access_token);

try
{

		if(!empty($Array))
		{
            $array['domain']            =  $_DOMAIN;
			httpPost('https://app.fashioncircle.de/merchants/delete',$array);
		}

$deleteRecord="DELETE from merchant_mvp_token where shopDomain='$_DOMAIN' ";
$executeDelete=mysqli_query($newCon,$deleteRecord);	
if($executeDelete)
{
	$response = 'True';
}
else
{
	$response = 'False';
}
fwrite($fh, $response);
mysqli_close($newCon);	
	/*

	$sc = new ShopifyClient($_DOMAIN,$shopToken,$api_key,$secret);
fwrite($fh, json_encode($sc));
$request = $sc->call('DELETE','/admin/products/10639550156.json');
fwrite($fh, 'Deletion response');
fwrite($fh, json_encode($request));
fwrite($fh, 'success response');

        if($num_rows>0)
{

	$sc = new ShopifyClient('fashioncirclede.myshopify.com', $shopToken, $api_key, $secret);
	fwrite($fh,'working');
	//$time_start = microtime(true);
	$url = '/admin/products.json?ids='.$shopProducts;
	fwrite($fh, $url);
	fwrite($fh, json_encode($sc));
	$getShopProducts = $sc->call('GET','/admin/products.json?ids='.$shopProducts);

	fwrite($fh,'its working');
	fwrite($fh, json_encode($getShopProducts));
	//mail("kamini_thakur@esferasoft.com","uninstall",'ShopProducts='.json_encode($getShopProducts));

	if(!empty($getShopProducts))
	{
		//mail("kamini_thakur@esferasoft.com","uninstall",'shop products are not empty');
		foreach ($getShopProducts as $key => $val) {
			$prodId = $val['id'];
			fwrite($fh, $prodId);
			$getMetafield = $sc->call('GET','/admin/products/'.$prodId.'/metafields.json?namespace=fashionCircleProduct');
			fwrite($fh, print_r($getMetafield, true));
			//mail("kamini_thakur@esferasoft.com","uninstall",'Metafields='.json_encode($getMetafield));
		
			if(!empty($getMetafield))
			{
				fwrite($fh, 'metafields contains');
				$key = array_search('fashionCircleProduct', array_column($getMetafield, 'namespace'));
		    	fwrite($fh, $key);
				$shopProdId = $getMetafield[$key]['owner_id'];
				fwrite($fh, 'shop prod id=');
				fwrite($fh, $shopProdId);
				$request = $sc->call('DELETE','/admin/products/'.$shopProdId.'.json');
			}
			else
			{
				fwrite($fh, 'doesnt have metafields');
			}
		}
	}
	else
	{
		fwrite($fh, 'doesnt have products of fashioncircle');
	}
		
}
else
{
		fwrite($fh, 'not going into loop');
}
*/

}
catch (ShopifyApiException $e)
    {
		
        //fwrite($fh, $e->getMethod());// -> http method (GET, POST, PUT, DELETE)
        fwrite($fh,$e->getPath());// -> path of failing request
        fwrite($fh,$e->getResponseHeaders());// -> actually response headers from failing request
        fwrite($fh,$e->getResponse());// -> curl response object
        fwrite($fh,$e->getParams());// -> optional data that may have been passed that caused the failure
		
    }

function httpPost($url, $data)
{
	global $fh,$mvp_access_token;
	fwrite($fh, $data);
    $curl = curl_init($url);
    curl_setopt ($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Access-Token: '.$mvp_access_token
    ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $res = json_decode($response);
    fwrite($fh, $res);
    if(isset($res->success))
    {
	 $responseArray['response'] = 'Success';
    }
    else
    {
     $responseArray['response'] = 'Failure';
    }
    fwrite($fh, json_encode($responseArray));
    
}
?>

