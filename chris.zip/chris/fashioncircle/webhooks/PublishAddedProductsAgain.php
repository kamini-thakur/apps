<?php

/* webhook fires when vendor re-installs the app on their vendor store so as to publish the hidden products again on all merchant store */

require '../shopify.php';
require '../keys.php';

$data     =file_get_contents('php://input');

$fh       =fopen('publishVendorProd.txt', 'w')  or fwrite($fh,"Utyftyftf");

//mail("kamini_thakur@esferasoft.com",'products','Deleting product from mvp is working');
fwrite($fh, $data);

$array = json_decode($data);

///////////// show products on merchant shopify store ///////////////

foreach($array as $key=>$val)
{
	fwrite($fh,'going');

	$token=$val->token;
	fwrite($fh,'json token'.$token);

	$shopify_domain = $val->shopify_domain;
	fwrite($fh,'json domain'.$shopify_domain);

	$PlatformProductId = (string)$val->PlatformProductId;
	fwrite($fh,'json id'.$PlatformProductId);

	fwrite($fh,'api key'.$api_key);
	fwrite($fh,'secret'.$secret);

	$sb = new ShopifyClient($shopify_domain, $token, $api_key, $secret);

	$update = array( "product" => array( "id" => $PlatformProductId, "published" => true ));

	$delProduct = $sb->call('PUT','/admin/products/'.$PlatformProductId.'.json',$update);
	fwrite($fh,'working'); 

	unset($sb);
}

?>