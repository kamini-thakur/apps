<?php
// error_reporting(E_ALL);
// ini_set("display_errors", 1);

require '../shopify.php';
require '../keys.php';

$data     =file_get_contents('php://input');

$fh       =fopen('deleteMVP.txt', 'w')  or fwrite($fh,"Utyftyftf");
// //fwrite($fh,'<<<<<<<AD is cool>>>>>>>>');
//fwrite($fh,'hello its working');
//mail("kamini_thakur@esferasoft.com",'products','Deleting product from mvp is working');
fwrite($fh, $data);
// fwrite($fh, '++++++'.print_r($data,true).'+++++++');
// fwrite($fh,'====='.var_export(json_decode($data), true).'=====');
// $d    =json_decode($_POST);
// $r  = var_export($r, true);
// fwrite($fh, $r);

$array = json_decode($data);

///////////// Hide products from shopify store ///////////////

foreach($array as $key=>$val)
{
	fwrite($fh,'going');

	$token=$val->token;
	fwrite($fh,'json token'.$token);

	$shopify_domain = $val->shopify_domain;
	fwrite($fh,'json domain'.$shopify_domain);

	$PlatformProductId = (string)$val->PlatformProductId;
	fwrite($fh,'json id'.$PlatformProductId);

	fwrite($fh,'api key'.$api_key);
	fwrite($fh,'secret'.$secret);

	$sb = new ShopifyClient($shopify_domain, $token, $api_key, $secret);

	$update = array( "product" => array( "id" => $PlatformProductId, "published" => false ));

	$delProduct = $sb->call('PUT','/admin/products/'.$PlatformProductId.'.json',$update);
	fwrite($fh,'working'); 

	unset($sb);
}

?>