<?php

$data = file_get_contents('php://input');
$fh= fopen('shopUpdate.txt', 'w');

fwrite($fh,$data);

//mail("kamini_thakur@esferasoft.com","shop update",'shop updated');

$Array    =json_decode($data);

?>