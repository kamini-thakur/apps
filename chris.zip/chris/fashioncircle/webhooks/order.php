<?php

require_once '../header.php';
require '../keys.php';
require '../shopify.php';
require '../database_config.php';

//echo "hjhj";

//$data = '{"id":5004258322,"email":"test@gmail.com","closed_at":null,"created_at":"2017-06-03T00:44:25-04:00","updated_at":"2017-06-03T00:44:26-04:00","number":5,"note":null,"token":"f639f0549f411673f2b0c6719269b98b","gateway":"Cash on Delivery (COD)","test":false,"total_price":"1954.38","subtotal_price":"1728.34","total_weight":0,"total_tax":"216.04","taxes_included":false,"currency":"USD","financial_status":"pending","confirmed":true,"total_discounts":"0.00","total_line_items_price":"1728.34","cart_token":"4153e3af6ab1ab3083b5ad825d88dcd6","buyer_accepts_marketing":false,"name":"#1005","referring_site":"","landing_site":"\/admin","cancelled_at":null,"cancel_reason":null,"total_price_usd":"1954.38","checkout_token":"e20d520e0e5d6e90b4959ffb96feda94","reference":null,"user_id":null,"location_id":null,"source_identifier":null,"source_url":null,"processed_at":"2017-06-03T00:44:25-04:00","device_id":null,"phone":null,"browser_ip":null,"landing_site_ref":null,"order_number":1005,"discount_codes":[],"note_attributes":[],"payment_gateway_names":["Cash on Delivery (COD)"],"processing_method":"manual","checkout_id":14255474130,"source_name":"web","fulfillment_status":null,"tax_lines":[{"title":"VAT","price":"216.04","rate":0.125}],"tags":"","contact_email":"test@gmail.com","order_status_url":"https:\/\/checkout.shopify.com\/20635177\/checkouts\/e20d520e0e5d6e90b4959ffb96feda94\/thank_you_token?key=b7f84d7f7fb8b079ef7a7cfe5bba69da","line_items":[{"id":9569343442,"variant_id":35592715538,"title":"test pass2","quantity":1,"price":"1728.34","grams":0,"sku":"SD23","variant_title":"","vendor":"Fashioncircle-test","fulfillment_service":"manual","product_id":9687608594,"requires_shipping":true,"taxable":true,"gift_card":false,"name":"test pass2","variant_inventory_management":"shopify","properties":[],"product_exists":true,"fulfillable_quantity":1,"total_discount":"0.00","fulfillment_status":null,"tax_lines":[{"title":"VAT","price":"216.04","rate":0.125}],"origin_location":{"id":3311501586,"country_code":"IN","province_code":"PB","name":"FashionCircleChris","address1":"SCF 20 , Phase 2","address2":"","city":"Mohali","zip":"160055"},"destination_location":{"id":3311504274,"country_code":"IN","province_code":"CH","name":"tester esfera","address1":"scf 30","address2":"","city":"mohali","zip":"160055"}}],"shipping_lines":[{"id":4159259794,"title":"Standard Shipping","price":"10.00","code":"Standard Shipping","source":"shopify","phone":null,"requested_fulfillment_service_id":null,"delivery_category":null,"carrier_identifier":null,"tax_lines":[]}],"billing_address":{"first_name":"tester","address1":"scf 30","phone":null,"city":"mohali","zip":"160055","province":"Chandigarh","country":"India","last_name":"esfera","address2":"","company":null,"latitude":30.7264274,"longitude":76.7076768,"name":"tester esfera","country_code":"IN","province_code":"CH"},"shipping_address":{"first_name":"tester","address1":"scf 30","phone":null,"city":"mohali","zip":"160055","province":"Chandigarh","country":"India","last_name":"esfera","address2":"","company":null,"latitude":30.7264274,"longitude":76.7076768,"name":"tester esfera","country_code":"IN","province_code":"CH"},"fulfillments":[],"client_details":{"browser_ip":"182.71.22.106","accept_language":"en-US,en;q=0.5","user_agent":"Mozilla\/5.0 (X11; Ubuntu; Linux i686; rv:53.0) Gecko\/20100101 Firefox\/53.0","session_hash":"aa8acdd2a09d93854534e74a26d94b9c","browser_width":1287,"browser_height":673},"refunds":[],"customer":{"id":5470010002,"email":"test@gmail.com","accepts_marketing":false,"created_at":"2017-06-02T00:09:21-04:00","updated_at":"2017-06-03T00:44:26-04:00","first_name":"tester","last_name":"esfera","orders_count":5,"state":"disabled","total_spent":"0.00","last_order_id":5004258322,"note":null,"verified_email":true,"multipass_identifier":null,"tax_exempt":false,"phone":null,"tags":"","last_order_name":"#1005","default_address":{"id":5912303186,"first_name":"tester","last_name":"esfera","company":null,"address1":"scf 30","address2":"","city":"mohali","province":"Chandigarh","country":"India","zip":"160055","phone":null,"name":"tester esfera","province_code":"CH","country_code":"IN","country_name":"India","default":true}}}';

$data     =(file_get_contents('php://input'));
$fh       =fopen('ffa.txt', 'w')  or die("Utyftyftf");
var_dump($fh);
fwrite($fh, $data);
fwrite($fh, '$_DOMAIN');

$array    =json_decode($data);
$tempVar  = var_export($array, true);
$Mydata   =array();
$sku      ="";

/* GET DOMAIN FROM HEDAERS  */
$_HEADERS = apache_request_headers();
$_DOMAIN  =$_HEADERS['X-Shopify-Shop-Domain'];
//$_DOMAIN = $_SESSION['shop'];
fwrite($fh, $_DOMAIN);

$sql="SELECT * from merchant_mvp_token where shopDomain='$_DOMAIN' ";
$qex=mysqli_query($newCon,$sql);
$res = mysqli_fetch_array($qex);
$mvp_access_token = $res['mvp_access_token'];
$shopToken = $res['shopToken'];
fwrite($fh,$mvp_access_token);
fwrite($fh,'shop token');
fwrite($fh,$shopToken);
/* requie files */
$line_items=array();
//echo 'working';
$tmp=array();
$tmp['domain'] = $_DOMAIN;
$tmp['platform'] = 'Shopify';
$tmp['OrderId'] = $array->id;
$tmp['paymentMethod'] = $array->gateway;
$tmp['financial_status']=$array->financial_status;
$tmp['OrderUrl'] = $array->order_status_url;

$sc = new ShopifyClient($_DOMAIN, $shopToken, $api_key, $secret);

foreach ($array->line_items as $key => $value) {
       
  $GetMeta = $sc->call('GET','/admin/products/'.$value->product_id.'/metafields.json?namespace=fashionCircleProduct');
  if(!empty($GetMeta))
  {
      $tmp['products'][$value->vendor]['obj-'.$key] = [
                        'ShopifyProductId'=>$value->product_id,
                        'ProductQty'         =>$value->quantity,
                          ];
  }
 //  fwrite($fh,'-->key--'.$key);
 // fwrite($fh, '<------>'.$value->id.'------------');
}

// echo '<pre>';
// print_r($tmp);
// echo '</pre>';

    /////////// Call to get the fashioncircle order products amounts ////////////
        $vendor = array();
        $order = array();

        foreach ($array->line_items as $key => $value) {

                if( isset($value->product_id) ) {
          
                   $GetMeta = $sc->call('GET','/admin/products/'.$value->product_id.'/metafields.json?namespace=FCProdPrice');
                  // echo '<pre>';
                  // print_r($GetMeta);
                  // echo '</pre>';
                   
                   if(!empty($GetMeta))
                   {
                     $key = array_search('FCProdPrice', array_column($GetMeta, 'namespace'));
                     $prodPrice=$GetMeta[$key]['value'];
                    
                     $vendor_name =str_replace('Fashioncircle-', '', $value->vendor);

                      if (array_key_exists($vendor_name,$vendor))
                      {
                          $vendor[$vendor_name] +=  ($prodPrice)*($value->quantity);
                      }
                      else
                      {
                          $vendor[$vendor_name] =  ($prodPrice)*($value->quantity);
                      }
                      $order['orderID'] = $array->id;
                      $order['orderNo'] = $array->order_number;  
                   }
                    
                } 
      }
      echo '<pre>';
      print_r($vendor);
      echo '</pre>';

      echo '<pre>';
      print_r($order);
      echo '</pre>';
     
      /////////// Call to Update the orders amounts of vendors ////////////

      foreach($vendor as $key => $val)
      {
        $orderID = $order['orderID'];
        $orderNo = '#'.$order['orderNo'];
        $response = insertPaymentDetails($key,$val,$orderID,$orderNo);
        fwrite($fh, $response);
      }

fwrite($fh, print_r($tmp, true));

fwrite($fh,'<!-----Order data goes here---->');

httpPost($postUrl.'/orders/place',$tmp);

function httpPost($url,$tmp)
{
        global $fh,$mvp_access_token;
         fwrite($fh, json_encode($tmp));

        $content = json_encode($tmp);

        fwrite($fh, '<------++++++++++++------------');


        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Access-Token: '.$mvp_access_token
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $str = 'order_detail='.$content;
        fwrite($fh, $str);

        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, ($str));
        $json_response = curl_exec($curl);

        print_r($json_response);

        fwrite($fh,$json_response);
        echo $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        if ( $status != 201 )
        {
         fwrite($fh,"Error: call to URL $url failed with status $status, response $json_response, curl_error " . curl_error($curl) . ", curl_errno " . curl_errno($curl));
        }
        fwrite($fh,'Curl Error: '.curl_error($fh));
        curl_close($curl);
   
}


function vendorDetails($url, $data)
{
  global $fh,$mvp_access_token;
  fwrite($fh, '<------+++++vendor details+++++++------------');
  fwrite($fh, json_encode($data));
    $curl = curl_init($url);
    //curl_setopt($curl, CURLOPT_HEADER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Access-Token: '.$mvp_access_token
    ));
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    fwrite($fh, '<------+++++vendor details response+++++++----------');
    //fwrite($fh, $response);

    curl_close($curl);
    $result = json_decode($response); 
    
    if(isset($result->success))
    {
      $responseArray['response'] = 'Success';
    }
    else
    {
     $responseArray['response'] = 'Failure';
    }
    fwrite($fh, json_encode($responseArray));
    return $response;
} 

function insertPaymentDetails($vendorName,$amount,$orderID,$orderNo)
{
    global $newCon,$_DOMAIN,$postUrl,$fh;
    
    $sql = "SELECT * from paymentDetails where shopDomain='$_DOMAIN' and vendorName = '$vendorName' and paymentStatus != 'Completed' ";
    $qex = mysqli_query($newCon,$sql);
    $res = mysqli_fetch_array($qex);
    $num_rows = mysqli_num_rows($qex);

    $array['vendorName']   =  $vendorName;

    $result = vendorDetails($postUrl.'/apis/get_vendor',$array);
    $result =  json_decode($result);
    fwrite($fh, $result->emailid);

    $vendorEmail = $result->emailid;
    if($num_rows == 0)
    {
      // add new row if payments are completed also or if they don't exist in databse
      $insertNewVendor="INSERT INTO paymentDetails(shopDomain,vendorName,vendorEmail,amount,orderNo,orderId,paymentStatus) VALUES('".$_DOMAIN."','".$vendorName."','".$vendorEmail."','".$amount."','".$orderNo."','".$orderID."','pending')";
        $qex=mysqli_query($newCon,$insertNewVendor); 
    }
    else
    {
      // update pending payments
      $UpdatedAmt = ($amount)+($res['amount']);
      if (!empty($res['orderNo'])) {
         $orderNo = $res['orderNo'].','.$orderNo;
      }
      if (!empty($res['orderId'])) {
         $orderID = $res['orderId'].','.$orderID; 
      }
      
        $updateVendor="UPDATE paymentDetails set amount='$UpdatedAmt',orderNo='$orderNo',orderId='$orderID',vendorEmail='$vendorEmail' where shopDomain='$_DOMAIN' and vendorName='$vendorName' and paymentStatus != 'Completed' ";
        $qex=mysqli_query($newCon,$updateVendor);
  
    }
    if($qex)
    {
      return 'Success';
    }
    else
    {
      return 'Error';
    }
}


?>