<?php 

require_once 'header.php';
require 'keys.php';
require 'shopify.php';
require 'database_config.php';

$Array= array();

$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
$shopURL='https://'.$_SESSION['shop'];

$_DOMAIN = $_SESSION['shop'];


try
        {

        date_default_timezone_set("Europe/Berlin");
        $t=time();
        $date=(date("Y-m-d",$t));
        $currentTime=(date("h:i:sa",$t));
 
        $request = $sc->call('GET','/admin/orders.json');
        //global $currentProdID='';
        //echo '/admin/orders.json?updated_at_min='.$date;

		if($_SESSION['shop'] == 'fashioncirclede.myshopify.com')
		{
			// echo '<pre>';
			// print_r($request);
			// echo '</pre>';
		}
        
		$shopCurrency = ($sc->call('GET', '/admin/shop.json?fields=money_format'));
		$money_format= $shopCurrency['money_format'];
		$symbol = explode("{{", $money_format);

		echo '<div class="pending-orders">';
        echo '<center><h3>Total amount to be paid to each vendor</h3></center><br><br>';

       echo '<div class="loading-dots" id="loading-dots">
				<center>
				<div class="loaderDots">Loading...</div>
				</center>
			</div>';
       
	   echo '<table class="table table-striped"><tr><th>Vendor Name</th><th>Total price</th><th>Orders</th><th>Action</th></tr>';

				$sql = "SELECT * from paymentDetails where shopDomain='$_DOMAIN' and paymentStatus != 'Completed' ";
				$qex = mysqli_query($newCon,$sql);
				$pending_num_rows = mysqli_num_rows($qex);
				//echo 'hello'.$pending_num_rows;
				
				while ($res = mysqli_fetch_array($qex)) {

						echo '<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" id="payOrder" target="_blank">';
						echo '<tr><td>'.$res['vendorName'].'</td><td>'.$symbol[0].$res['amount'].'</td>';

						$orderNo=explode(",",$res['orderNo']);
						$orderId=explode(",",$res['orderId']);

						$orderDetails = array_combine($orderId, $orderNo);
						echo '<td>';
						foreach ($orderDetails as $key => $val) {
						   echo '<a href="'.$shopURL.'/admin/orders/'.$key.'" target="_blank">'.$val.'</a>  ';
						}
						echo '</td>';

						echo '<input type="hidden" name="cmd" value="_xclick" />';
						echo '<input type="hidden" name="charset" value="utf-8" />';
						echo '<input type="hidden" name="business" value="'.$res['vendorEmail'].'" />';
						echo '<input type="hidden" name="item_name" value="Pay '.$res['vendorName'].'" />';
						echo '<input type="hidden" name="custom" value="'.$res['id'].'='.$_DOMAIN.'" />';
						echo '<input type="hidden" name="currency_code" value="USD" />';
						echo '<input type="hidden" name="amount" value="'.$res['amount'].'" />';
						echo '<input type="hidden" name="notify_url" value="https://shopify.fashioncircle.de/fashioncircle/ipn.php" />';
						echo '<input type="hidden" name="return" value="https://shopify.fashioncircle.de/fashioncircle/return.php" />';
						echo '<input type="hidden" name="cancel_return" value="https://shopify.fashioncircle.de/fashioncircle/cancel_return.php" />';

						echo '<td><button type="submit" name="sendPayment" id="payViaPaypal" value="Pay with paypal"><img src="assets/images/paypalCheck.png" alt="PayPal"></button><td></tr>';	
						echo '</form>';
				}

		echo '</table>';

		echo '</div>';
		echo '<div class="Completed-orders">';
		echo '<center><h3>Paid orders</h3></center><br><br>';
		echo '<table class="table table-striped"><tr><th>Vendor Name</th><th>Total price</th><th>Orders</th><th>Status</th></tr>';

		$sql = "SELECT t1.* , t2.* from transactionDetails t1 join paymentDetails t2 on t1.paymentId = t2.id and t1.shopDomain='$_DOMAIN' and t1.paymentStatus = 'Completed' ";
		$qex = mysqli_query($newCon,$sql);
		$complete_num_rows = mysqli_num_rows($qex);
		//echo 'hello'.$complete_num_rows;
		while ($res = mysqli_fetch_array($qex)) {

				echo '<tr><td>'.$res['vendorName'].'</td><td>'.$symbol[0].$res['amountPaid'].'</td>';
				$orderNo=explode(",",$res['orderNo']);
				$orderId=explode(",",$res['orderId']);

				$orderDetails = array_combine($orderId, $orderNo);
				echo '<td>';
				foreach ($orderDetails as $key => $val) {
				   echo '<a href="'.$shopURL.'/admin/orders/'.$key.'">'.$val.'</a>  ';
				}
				echo '</td>';

				echo '<td><input class="btn btn-success" type="button" value="Paid"><td></tr>';	
		}
		echo '</table></div>';
		
}
catch (ShopifyApiException $e)
    {
		
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
		
    }



?>
<script type="text/javascript">
		var pending_num_rows = '<?php echo $pending_num_rows; ?>';
		var complete_num_rows = '<?php echo $complete_num_rows; ?>';
		
		if(complete_num_rows == 0)
		{
			$('.Completed-orders').css('display','none');
		}
		if(pending_num_rows == 0)
		{
			$('.pending-orders').css('display','none');
		}

		// alert('complete'+complete_num_rows);
	$('form#payOrder').submit(function(e){
		
		$('#loading-dots').show();
		setTimeout(function(){ $('#loading-dots').hide(); }, 5000);
		window.location.reload();
	});
</script>
