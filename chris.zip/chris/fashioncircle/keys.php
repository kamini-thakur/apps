<?php

$api_key = "565a0992dcbc1227bbea59a645cfa8b2";
$secret = "3794215d4ad44226b0c45de18462bfb8";

$postUrl = 'https://app.fashioncircle.de';

?>