<?php

$data     =(file_get_contents('php://input'));
$fh       =fopen('d.txt', 'w')  or fwrite($fh,"Utyftyftf");;

fwrite($fh, $data);

?>