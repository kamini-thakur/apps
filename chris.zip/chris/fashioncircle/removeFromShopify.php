<?php
session_start();
require 'keys.php';
require 'shopify.php';
$_DOMAIN = $_SESSION['shop'];
$Array = array();
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
$productId = $_POST['platform_product_id'];


try
        {
        $request = $sc->call('DELETE','/admin/products/'.$productId.'.json');
        if(empty($request))
           {
                 $array['PlatformProductId'] = (int)$productId;
                 $array['domain']            =  $_SESSION['shop'];
                 httpPost('https://app.fashioncircle.de/merchants/products/delete',$array);
           }

}
catch (ShopifyApiException $e)
    {
		
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
		
    }


function httpPost($url, $data)
{
    $curl = curl_init($url);
    curl_setopt ($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Access-Token: '.$_SESSION['mvp_access_token']
    ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $res = json_decode($response);
    if(isset($res->success))
      {
	 $responseArray['response'] = 'Success';
	 $responseArray['mvpId']       = $res->product_id;
        
      }
      
      else
      {
       $responseArray['response'] = 'Failure';
      }
    echo  json_encode($responseArray);
    
}

?>