<?php

require_once 'header.php';
require 'keys.php';
require 'shopify.php';
require 'database_config.php';


if(!$_SESSION['shop'])
{
   header('Location: login.php');
}


$_DOMAIN=$_SESSION['shop'];
$_SESSION['token'];


$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
$_SHOP = ($sc->call('GET', '/admin/shop.json?fields=email,name,domain,myshopify_domain'));
//print_r($_SHOP);

$_SHOP['platform']= 'Shopify';
$_SHOP['token']   = $_SESSION['token'];
$baseURL = 'https://shopify.fashioncircle.de';

//echo 'Token'.$_SESSION['token'];
//////////Create Webhooks as well as check it///////////

$url ='/admin/webhooks.json';

 $array=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/fashioncircle/webhooks/order.php');
      $meta=array
                           (
                    "webhook"=>array 
                    (
                     "topic"=> "orders/create",
                     "address"=> $baseURL."/fashioncircle/webhooks/order.php",
                     "format"=>"json"
                            )
                         );
    

          if (empty($array)) {
           
            $sc->call('POST', $url,$meta);
        }

//////////// Create product deletion webhook ////////////

$prodArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/fashioncircle/webhooks/prodDelete.php');
      $prodMeta=array
                (
                    "webhook"=>array 
                    (
                     "topic"=> "products/delete",
                     "address"=> $baseURL."/fashioncircle/webhooks/prodDelete.php",
                     "format"=>"json"
                            )
      );
    

          if (empty($prodArray)) {
           
            $sc->call('POST', $url,$prodMeta);
        }       


//////////// Create app uninstallation webhook ////////////

$uninstallArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/fashioncircle/webhooks/uninstall.php');
      $uninstallMeta=array
      (
                    "webhook"=>array 
                    (
                     "topic"=> "app/uninstalled",
                     "address"=> $baseURL."/fashioncircle/webhooks/uninstall.php",
                     "format"=>"json"
                    )
      );
    

      if (empty($uninstallArray))
      {     
          $sc->call('POST', $url,$uninstallMeta);
      }       

//////////// Create shop update webhook ////////////
/*
$shopUpdateArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/fashioncircle/webhooks/shopUpdate.php');
      $shopUpdateMeta=array
      (
                    "webhook"=>array 
                    (
                     "topic"=> "shop/update",
                     "address"=> $baseURL."/fashioncircle/webhooks/shopUpdate.php",
                     "format"=>"json"
                    )
      );
    

      if (empty($shopUpdateArray))
      {     
          $sc->call('POST', $url,$shopUpdateMeta);
      }       

*/
//////////////////////////////////////////////////////


$Account = httpPost('https://app.fashioncircle.de/merchants/add',$_SHOP);
//var_dump($Account);

if (isset( $Account->error )) {
   echo "<div class='notification-message'>".$Account->error."</div>";
   die();
}
 if(isset( $Account->is_enabled ) && !$Account->is_enabled)
    {
     echo "<div class='notification-message'>Thank You for installing Fashion Circle APP. Your Merchant Account status is 'Confirmation pending' from the Administrator. You will be notified once we activate your account. If you do not hear from us in 2 Weeks, please email us at 'sales@fashioncircle.de'.";
     die();
    }
$_SESSION['mvp_access_token'] = $Account->access_token; 

$shopURL='https://'.$_SESSION['shop'];

//////////////// Save MVP access token in database//////////////////
  $shopDomain = $_SESSION['shop'];
  $shopToken = $_SESSION['token'];

if(isset($_SESSION['mvp_access_token']))
{ 
  $sql="SELECT * from merchant_mvp_token where shopDomain='$shopDomain' ";
  $qex=mysqli_query($newCon,$sql);
  $num_rows=mysqli_num_rows($qex);
  
  if($num_rows==0)
  { 
     $sql="INSERT INTO merchant_mvp_token(mvp_access_token,shopDomain,shopToken)VALUES('".$_SESSION['mvp_access_token']."','".$shopDomain."','".$shopToken."')";
     $qex=mysqli_query($newCon,$sql); 
  }
  else
  {
     $sql="UPDATE merchant_mvp_token set mvp_access_token='".$_SESSION['mvp_access_token']."',shopToken='".$shopToken."' where shopDomain='".$shopDomain."' ";
     $qex=mysqli_query($newCon,$sql);
  }
  
}

////////////////////////////////////////////
$shopCurrency = ($sc->call('GET', '/admin/shop.json?fields=currency,money_format'));
$toCurrency=$shopCurrency['currency'];
$money_format= $shopCurrency['money_format'];
$symbol = explode("{{", $money_format); 
//echo $symbol[0];

$ConvertCurrency = 'http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20yahoo.finance.xchange%20where%20pair%20in%20(%22EUR'.$toCurrency.'%22)&env=store://datatables.org/alltableswithkeys&format=json';
$ConvertCurrency = file_get_contents($ConvertCurrency);
if($ConvertCurrency)
{
  $converted=json_decode($ConvertCurrency);  
  $rate=$converted->query->results->rate->Rate;
}

      ?>

<body id="shopifyAPP">
<div class="loading-dots" id="loading-dots">
<center>
<div class="loaderDots">Loading...</div>
</center>
</div>
<?php
$i = 0;
$result = $sc->getProducts();

// echo '<pre>';
// print_r($result);
// echo '</pre>';

echo '<a href="billingDetails.php" style="margin-left:40px; margin-top:40px;"><button class="btn btn-warning">Orders</button></a>';
// echo '<a href="merchant_paypal_details.php" style="margin-left:40px; margin-top:40px;"><button class="btn btn-warning">Paypal account Details</button></a>';

echo '<div class="ProductDiv">';
echo '<ul class="product-lists">';
foreach ($result as $key => $value) {
if($value->vendor_access=="yes")
{
  if ($value->is_app_uninstall=="1" && $value->vendor_mvp_platform_id!="0") {
    // Vendor has uninstalled the vendor plugin, so hide store products
  }
  else
  {

      if(!$value->platformProductId)
      {
      echo '<li class="carousel-list-item">';
      }
      else
      {
        echo '<li class="addedProduct carousel-list-item">';
      }
    echo '<form id="form-'.$value->id.'">';

    $total_price = ($value->dropshipping_price+($value->dropshipping_price)*($value->commission/100));
    $getprice=($total_price)*($rate);

    echo '<input type="hidden" name="title" value="'.$value->title.'">';
    echo '<input type="hidden" name="price" data-total-price="'.$total_price.'" value="'.round($getprice,2).'">';

    foreach ($value->images as $k => $v)
    {
      echo '<input type="hidden" name="image[]" value="'.$v.'">';
    }

    // echo '<input type="hidden" name="image" value="'.$value->images[0].'">';
    echo '<input type="hidden" name="description" value="'.$value->description.'<p><h4><q>Shipped directly by label</q></h4></p>">';
    echo '<input type="hidden" name="sku" value="'.$value->sku.'">';
    echo '<input type="hidden" name="vendor" value="'.$value->vendor.'">';
    echo '<input type="hidden" name="user_id" value="'.$value->user_id.'">';
    echo '<input type="hidden" name="mvp_product_id" value="'.$value->id.'">';
    echo '<input type="hidden" name="quantity" value="'.$value->quantity.'">';
    echo '<input type="hidden" id="platform_product_id'.'-'.$value->id.'" name="platform_product_id" value="'.$value->platformProductId.'">';

    $a = 0;
    $r =1;
    // echo '<div class="ProductImg mainprodImg"><img src="'.$value->images[0].'" /></div>';

    echo '<div class="ProductImg showAllProds fotorama" data-loop="true" data-allowfullscreen="true" >';
   
    foreach ($value->images as $k => $v)
    { 
      echo '<img src="'.$v.'" />';
    }
 
    echo '</div>';

    echo '<div class="ProductDesc">';
    echo '<span class="ProductTitle">'.$value->title.'</span>';
    echo '<span class="ProductVendor">'.$value->vendor.'</span>';
    echo '<span class="ProductPrice" data-price-euro="'.$value->dropshipping_price.'">'.$symbol[0].round($getprice,2).'</span>';

    if(!$value->platformProductId)
    {
     echo '<div class="OnHover"><input type="submit" value="Add to Shopify" id="button-'.$value->id.'" onclick="ProductEvent(event,'.$value->id.','.$a.')" /></div>';
    }
    else
    {
     echo '<div class="OnHover"><input type="submit" value="Remove from Shopify" id="button-'.$value->id.'" onclick="ProductEvent(event,'.$value->id.','.$r.')" /></div>';
    }
    echo "</div>";


    echo '<div class="available-qty"> Quantity Available: <span>'.$value->quantity.'</span></div>';
    echo '</form>';
    echo '</li>';
    ++$i;
  }
}
elseif ($value->vendor_access=="no") {
   // no vendor product access
 }
}

echo '</ul>';
echo '</div>';

function httpPost($url, $data)
{
    $responseArray = array();
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
      'Api-Key: pbkdf2_sha256$29000$p7lpJChcK4Lo$IHMul9j5lcPNJP4f/W1nXZknVi2N+GJIR1tZCo5C7uM='
       ));
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $res = json_decode($response);
    return $res;
    
}
?>
</body>
</html>


 <script type="text/javascript">
    ShopifyApp.init({
      apiKey: '<?php echo $api_key; ?>',
      shopOrigin:"<?php echo $shopURL; ?>",

      debug: true
    });
    </script>
<script type="text/javascript">
  ShopifyApp.ready(function(){
    ShopifyApp.Bar.initialize({
      
      title: 'Fashion Circle',
          callback: function(){ 
            ShopifyApp.Bar.loadingOff();
            
          }
    });
  });
  </script>

<script>

$(document).ready(function(){
$('.fotorama__fullscreen-icon').css('display','none');
$('div.fotorama__arr').addClass('fotorama__arr--disabled');
$("div.fotorama__arr").attr( "disabled", "disabled" );
$("div.fotorama__arr").attr("tabindex","-1");
// $('.fotorama').fotorama();

var fotoramaImg = $('.fotorama__img');
  fotoramaImg.each(function(){
  console.log('yes');
             var activeImg = $(this).css('top','0px');
           });

});

$(".ProductImg").hover(function(){
    $(this).find(".fotorama__fullscreen-icon").css('display','block');
    $(this).find('div.fotorama__arr').removeClass('fotorama__arr--disabled');
    $(this).find("div.fotorama__arr").attr( "disabled", "" );
    $(this).find("div.fotorama__arr").attr("tabindex","0");
    }, function(){
    $(this).find('div.fotorama__arr').addClass('fotorama__arr--disabled');
    $(this).find("div.fotorama__arr").attr( "disabled", "disabled" );
    $(this).find("div.fotorama__arr").attr("tabindex","-1");
});


  // var owl = $('.owl-demo');
  // owl.owlCarousel({      
  //         // autoPlay: false, //Set AutoPlay to 3 seconds
  //         // items : 4,
  //         loop : true,
  //         nav: false,
  //         singleItem: true
  // });
  // $('.owl-demo').slick({
  //     autoplay: false,
  //     dots: false,
  //     arrows: false,
  //     infinite: true,
  //     fade: true,
  //     autoplaySpeed: 1000,
  //     // speed: 100,
  //     slidesToShow: 1,
  //     slidesToScroll: 1
  // });



  // $(".owl-demo").on('mousemove', function(e) {

  //   var offset = $(this).offset();
  //   var position = (e.pageX - offset.left);
  //   if (position < $(this).width() / 2)
  //   {
  //     $('li.carousel-list-item').mouseover(function()
  //       {
  //       // $(this).slick('slickGoTo',0);
  //         //var myVar = setInterval(function(){ console.log('yes'); $('.owl-demo').slick('slickPrev'); }, 500);
        
  //         //$(this).slick('slickPrev');

  //         //$(this).find('.owl-demo').slick('slickPause');
  //         $(this).find('.owl-demo').slick('slickGoTo',0);
  //         $(this).find('.owl-demo').slick('slickPlay');

  //      });
  //   }
  //   else
  //   {
  //     // $('.owl-demo').mouseover(function()
  //     // {
  //     //     // $(this).slick('slickGoTo',0);
  //     //   var myVar = setInterval(function(){ $().slick('slickNext'); }, 500);
  //     //    // $(this).slick('slickNext');
  //     // });


  //   }

  // });

  
    // $('li.carousel-list-item').mouseover(function()
    // {
    //   $(this).find('.owl-demo').slick('slickPlay');
    //   //$(this).slick('slickPlay');
    //   //$(this).trigger('owl.play', 1000);
    // });
    // $('li.carousel-list-item').mouseout(function()
    // {
    //   $(this).find('.owl-demo').slick('slickPause');
    //   $(this).find('.owl-demo').slick('slickGoTo',0);
    //     //$(this).trigger('owl.stop');
    // });

  </script> 

<script type="text/javascript">
  
function ProductEvent(e,i,type)
{
    //window.location.href = "merchant_paypal_details.php";
    $('#loading-dots').show();
    e.preventDefault();
    console.log(i);
    
   //= new FormData(f);

    var xhr = new XMLHttpRequest();
    if(!type)
    {
      var url = 'AddToShopify.php';
      var d = $('form#form-'+i).serialize();
    }
    
    else
    {
      var url = 'removeFromShopify.php';
       var d = 'platform_product_id='+$('#platform_product_id-'+i).val();
    }
    
    xhr.open('POST', url, true);
   
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(d);
    xhr.onreadystatechange = function() {
    // If the request completed
   
     if (xhr.readyState == 4)
          {         //statusDisplay.innerHTML = '';
       if(xhr.status == 200) {          
              var d= (xhr.responseText);
              obj = JSON.parse(d);
              if(obj.response === 'Success')
               {               
                  var t = parseInt(obj.mvpId);
                  var buttonId= 'button-'+t;
                  var i ='platform_product_id-'+t;
                  
                  var o = e.target.getAttribute('id');
                  console.log(o);
                 
                  if(parseInt(type))
                   {
                      document.getElementById(i).value= '';
                      document.getElementById(o).parentElement.innerHTML = '<input type="submit" value="Add to Shopify" id='+buttonId+' onclick="ProductEvent(event,'+t+',0)" />';   
                      $('#'+buttonId).parent().closest('li').removeClass('addedProduct');   
                   }
                   else
                   {
                     var value = parseInt(obj.id);
                     console.log(value);
                     document.getElementById(i).value= value;
                     document.getElementById(o).parentElement.innerHTML = '<input type="submit" value="Remove from Shopify" id='+buttonId+' onclick="ProductEvent(event,'+t+',1)" />';
                     $('#'+buttonId).parent().closest('li').addClass('addedProduct');
                   }

                  $('#loading-dots').hide();                         
               }

          }
             
        }
        $('#loading-dots').hide(); 
       
    }
}

</script>

<style>
  /*29-march*/
 

</style>

