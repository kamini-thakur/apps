function addProducts(e,i)
{
  console.log(i);
  e.preventDefault();
  var f = document.querySelector(i);
  var d = new FormData(f);
  var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.send();
    xhr.onreadystatechange = function() {
        // If the request completed
        console.log(xhr.readyState);
        if (xhr.readyState == 4) {
            //statusDisplay.innerHTML = '';
            if (xhr.status == 200) {          


              
            } 
        }
    }
}