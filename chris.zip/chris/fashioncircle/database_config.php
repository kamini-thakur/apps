<?php
 
// $_USER_NAME='appslive_fraud';
// $_HOST     ='localhost';
// $_PASSWORD = '1!Amareye4fraud';
// $_DATABASE = 'appslive_eye4fraud';
// $con=mysqli_connect($_HOST, $_USER_NAME,$_PASSWORD,$_DATABASE);
// if (mysqli_connect_errno())
//   {
//   echo "Failed to connect to MySQL: " . mysqli_connect_error();
//   }


$_HOST     = 'localhost';
$_USER_NAME= 'root';
$_PASSWORD = 'digitalocean1234';
$_DATABASE = 'MVP';
$newCon=mysqli_connect($_HOST, $_USER_NAME,$_PASSWORD,$_DATABASE);
if(mysqli_connect_errno())
{
	echo "connection failed";
}

?>