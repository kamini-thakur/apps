<?php
require_once 'header.php';
require 'keys.php';
require 'shopify.php';
$_DOMAIN=$_SESSION['shop'];

//echo '<center><h2 style="display:none;" class="redirect">Please wait while we are redirecting you on shoopify store</h2></center>';
echo '<center><h2>Thank You :)</h2></center>';

?>

<script type="text/javascript">
	
	setTimeout(function(){
		//$('.redirect').css('display','block');
		var shopDomain= '<?php echo $_DOMAIN; ?>';
		//alert(shopDomain);
	 	window.location = 'https://'+shopDomain+'/admin/apps/';

	}, 2000);


</script>