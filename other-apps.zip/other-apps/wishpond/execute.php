<?php
     session_start();
     
     ini_set('display_errors', 1);
     ini_set('display_startup_errors', 1);
     error_reporting(E_ALL);
     if(!isset($_SESSION['shop']))
        {
        	header('location:login.php');
        }
     require 'database_config.php';
     require 'functions.php';
     require_once 'shopify.php';
     require_once 'keys.php';


     $sc           = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
     $_DOMAIN      = $_SESSION['shop'];
     $_TOKEN       = $_SESSION['token'];
     
     $MerchantKey  = mysqli_real_escape_string($con,trim($_POST['InputMerchantKey']));
  	 $TrackingKey  = mysqli_real_escape_string($con,trim($_POST['InputTrackKey']));
  	 if (empty($MerchantKey) || empty($TrackingKey)) {
  	 	# code...
  	 	echo "false";
  	 	die();
  	 }

  	
  	 $result = getDetails();
  	 if (getRows($result)) {
  		$CallResult = updateDetails($MerchantKey,$TrackingKey);
  	 }

  	 else
  	 {
  		$CallResult = insertTrackingDetails($MerchantKey,$TrackingKey);
  	 }

    if (!$CallResult) {
      echo "false";
    }
    else
    {
      echo 'true';
    /////////////////////////////////////////////////
            $ApiCallUrl         ='/admin/themes/'.$_SESSION['themeId'].'/assets.json?asset[key]=layout/theme.liquid&theme_id='.$_SESSION['themeId'];
            $themeFileContent   =$sc->call('GET',$ApiCallUrl);
            $themePostUrl       = 'admin/themes/'.$_SESSION['themeId'].'/assets.json';
            //file_put_contents('theme.txt',$themeFileContent['value']);

            $array              = $sc->call('GET', $themePostUrl);
            $findme             = 'WishPondSnippet';
            $pos                = strpos($themeFileContent['value'], $findme);

            //////////////////////////////////////////////////////
            if (!$pos) {
              # code...
            
            $EndBodyTagpos      = strpos($themeFileContent['value'], '</body>');                
            $newThemeLayout     = str_replace("</body>", "{% include 'WishPondSnippet' %}</body>", $themeFileContent['value']);
                 //file_put_contents('theme.txt',$newThemeLayout);
             $fileToCopy        = array(
                                          "asset" => array(
                                                "key"=> "layout\/WishPondbckupTheme.liquid",
                                                "source_key"=> "layout\/theme.liquid"
                                            )
                                        );
             $ApiCallToChangeThemeLiquidFile = $sc->call('PUT', $themePostUrl, $fileToCopy);    
             $themeFileContents = base64_encode($newThemeLayout);
             $fileToAttach      = array(
                                    "asset" => array(
                                        "key" => "layout/theme.liquid",
                                        "attachment" => $themeFileContents
                                                    )
                                      );

            $ApiCallToChangeThemeLiquidFile = $sc->call('PUT', $themePostUrl, $fileToAttach);
           
          }


             /////////////////////////////////////////////////////////


              #######################################################
                     
                     
                                    ///////////////
               $key = array_search('snippets/WishPondSnippet.liquid',array_column($array, 'key'));                            
                                $WishpondText = file_get_contents('liquid/snippet.txt');
                                // Provides: <body text='black'>
                                $WishpondText = str_replace("YOUR_MERCHANT_ID",  $MerchantKey, $WishpondText);
                                $WishpondText = str_replace("YOUR_TRACKING_KEY", $TrackingKey, $WishpondText);
                                $WishpondText = base64_encode($WishpondText);
                                $fileToAttach = array(
                                                "asset" => 
                                                  array(
                                                  "key"        => "snippets/WishPondSnippet.liquid",
                                                  "attachment" => $WishpondText
                                                       )
                                                    );
                                try{
                                $ApiCallToAddSnippet = $sc->call('PUT', $themePostUrl, $fileToAttach);
                                //echo "true";
                               // header('location:index.php?themeUpdate=success');
                                }
                                catch (ShopifyApiException $e) {
                                    
                                    //var_dump($e->getMethod()); // -> http method (GET, POST, PUT, DELETE)
                                   // var_dump($e->getPath()); // -> path of failing request
                                   // var_dump($e->getResponseHeaders()); // -> actually response headers from failing request
                                    var_dump($e->getResponse()); // -> curl response object
                                   // var_dump($e->getParams()); // -> optional data that may have been passed that caused the failure
                                    
                                }
  }
                          
                                    //////////////


 ?>