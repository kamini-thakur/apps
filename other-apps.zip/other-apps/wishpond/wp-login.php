<!DOCTYPE html>
<html>
<head>
  <meta content="IE=edge" http-equiv="X-UA-Compatible">
  <meta charset="utf-8">
  <meta content="user-scalable=no, width=device-width, maximum-scale=1.0" name="viewport">
  <title>Wishpond Sign Up</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://wishpondapps.com/assets/css/style.css">
</head>
<body>

  <div class="container wishpondLoginFrm" style="display: <?php echo $displayLogin ?>;">
    <div class="row">
      <div class="col-sm-12">
        <form accept-charset="UTF-8" action="" class="new_user loginForm" id="new_user" method="post">
          <div class="form-group">
            <label for="exampleInputEmail1">Email address:</label>
            <input aria-describedby="email_help_block" class="form-control" id="user_email" name="user[email]" size="30" type="email">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password:</label>
            <input aria-describedby="password_help_block" autocomplete="false" class="form-control" id="user_password" name="user[password]" size="30" type="password">
          </div>
          <button name="commit" type="submit" id="login_wishpond" data-url="https://www.wishpond.com/session?redirect_to=https%3A%2F%2Fwww.wishpondapps.com%2Flogin.php" data-form-type="loginForm" class="btn btn-default" onclick="return false;">Sign Up Free</button>
        </form>
        <!-- postForm('https://www.wishpond.com/session?redirect_to=https%3A%2F%2Fwww.wishpondapps.com%2Flogin.php','loginForm'); -->
      </div>
      <div class="col-sm-12">
        <p class="text-center card_footer_text">Don't have an account? <strong><a href="/wp-signup.php">Start Free Trial</a>.</strong></p>
      </div>
    </div>
  </div>
</body>
</html>

<?php

require_once 'footer.php';

?>

