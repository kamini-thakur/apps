<?php

require_once 'header.php';

?>

<body>
  <div class="container">
    <div class="row">
      <div class="col-sm-12 text-center">
        <img class="wishpond-blue" src="https://d3ds0r8ijvk7u6.cloudfront.net/wp-content/uploads/sites/3/2017/05/10104712/wishpond-shopify.png" alt="wishpond logo">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12 form-container">
        <h4>Success!</h4>
        <p>Your Wishpond Tracking code has been installed in your Shopify theme!</p>
        <p><a href="https://www.wishpond.com/wizard/start?landing_page_type=popups&participation_type=landing_page&sub_type=none&wizard=wizards%2Flanding_page_v2" class="btn btn-success">Create Your Popup Now</a></p>
      </div>
    </div>
    <div class="wishpond-outer">
      <div class="loader"></div>
    </div>
  </div>
</body>
</html>