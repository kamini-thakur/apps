<?php
 
$_USER_NAME= 'partnerdb';
$_HOST     = 'localhost';
$_PASSWORD = '$rTQ!jMV!SZZ^PKcMB*za5y*sC2rNPEvMmz';
$_DATABASE = 'wishpond';
$con=mysqli_connect($_HOST, $_USER_NAME,$_PASSWORD,$_DATABASE);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>