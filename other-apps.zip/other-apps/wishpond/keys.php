<?php

$api_key = '86250263bc08bf8442e365d7c82dbd32';
$secret = 'fad4b740fffc97dc0fd43de15c6a998b';

?>