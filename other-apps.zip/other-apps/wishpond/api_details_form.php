
<?php

require_once 'database_config.php';
require_once 'functions.php';
$MerchantKey='';
$TrackingKey='';
$obj   = getDetails();
$array = getApiDetails($obj);

if (!empty($array)) {
  $MerchantKey = $array['MerchantKey'];
  $TrackingKey = $array['TrackingKey'];
}

if (isset($_GET['type']) && $_GET['type'] == 'q' ) {
  $display_content = 'block';
}
else
{
  $display_content = 'none'; 
}

?>

<body>
  <div class="container wishpondTrackForm" style="display: <?php echo $display_content ?>;">
    <div class="row">
      <div class="col-sm-12 text-center">
        <img class="wishpond-blue" src="https://d3ds0r8ijvk7u6.cloudfront.net/wp-content/uploads/sites/3/2017/05/10104712/wishpond-shopify.png" alt="wishpond logo">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12 form-container">
        <h4>Please fill the details below to add your Wishpond tracking code to your store</h4>
        <p><a href="https://www.wishpond.com/login" target="_blank">Click here to get your Wishpond keys</a></p>
        <form method="POST" action="#" id="wishPondTrackingForm">
          <div class="form-group">
            <label for="WishPondMerKey">Merchant ID:</label>
            <input type="text" class="form-control" id="WishPondMerKey" name="InputMerchantKey" required="true" value="<?php echo $MerchantKey; ?>">
          </div>
          <div class="form-group">
            <label for="WishPondTrackKey">Tracking Key:</label>
            <input type="text" class="form-control" id="WishPondTrackKey" name="InputTrackKey" required="true" value="<?php echo $TrackingKey; ?>">
          </div>
          <small class="input-error hide"><p>Invalid Tracking Key. Please enter a valid Tracking Key.</p></small>
          <button type="submit" class="btn btn-success btn-submit" name="submitShopDetails">Submit</button>
        </form>
      </div>
    </div>
    <div class="wishpond-outer">
      <div class="loader"></div>
    </div>
  </div>