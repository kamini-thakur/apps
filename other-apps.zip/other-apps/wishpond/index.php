<?php

require_once 'header.php';

require_once 'shopify.php';

require_once 'keys.php';

$_DOMAIN   = $_SESSION['shop'];

if(empty($_DOMAIN))
{
  header('Location: login.php');
}
// require_once 'wp-login.php';

require_once 'wp-signup.php';

require_once 'api_details_form.php';

$sc                  = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
$_SHOP_DETAILS       = $sc->call('GET', '/admin/themes.json?role=main');
$_THEME_ID           = $_SHOP_DETAILS[0]['id'];
$_SESSION['themeId'] = $_THEME_ID;
//////GET /admin/shop.json

require_once 'footer.php';

?>




