<?php

function insertTrackingDetails($merchantKey,$trackingKey)
  {
       global $con,$_DOMAIN;
       $query="INSERT INTO ShopifyDetails (shopifyDomain,accessToken,merchantKey,trackingKey) VALUES('".$_DOMAIN."','".$_SESSION['token']."','".$merchantKey."','".$trackingKey."')";
       $success_rate=(mysqli_query($con,$query));
       if(!$success_rate)
         {
           return false;
         }
      else 
         {
           return true;
         } 
  }


function updateDetails($merchantKey,$trackingKey)
  {
     global $con,$_DOMAIN;
       $query="UPDATE ShopifyDetails  SET merchantKey='".$merchantKey."', trackingKey='".$trackingKey."' WHERE shopifyDomain='".$_DOMAIN."'";

       $success_rate=(mysqli_query($con,$query));
       if(!$success_rate)
         {
          return false;
          
         }
         else{

          return true;
         } 
  }


 function getDetails()
   {
      global $con,$_DOMAIN;
      $query="SELECT * FROM ShopifyDetails where shopifyDomain='".$_DOMAIN."'";
      $result=mysqli_query($con,$query);
      
      return $result;
   }


function getApiDetails($obj)
  {
      $row=mysqli_fetch_assoc($obj);
      $array = array();

      if(!empty($row['merchantKey'] && !empty($row['trackingKey'])))
      {

          $array['MerchantKey']   = $row['merchantKey'];
          $array['TrackingKey']   = $row['trackingKey'];

         }

        return $array;
  }

function getRows($obj)
   {
    return mysqli_num_rows($obj);
   }



?>