jQuery.noConflict();
(function($) {
	$(function() {
	var tForm = $('form#wishPondTrackingForm');
		tForm.submit(function(e){
			e.preventDefault();
			$('.input-error').addClass('hide');
			//$('.wishpond-outer').show();
			var data = tForm.serialize();
			$.ajax({
				method: "POST",
				url: "execute.php",
				data: data,
			}).done(function( msg ) {
				//$('.wishpond-outer').hide();
				switch(msg) {
					case 'false':
						alert('Something went wrong, cannot proceed');
						$('.input-error').removeClass('hide');
						break;
					case 'true':
						alert('Keys updated');
						window.location.href = 'https://wishpondapps.com/thank-you/';
						break;
					default:
						alert('Cannot proceed with request, please try again');
					}
			});
		});


	});
})(jQuery);