  <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script type="text/javascript" src="assets/js/common.js"></script>

<script type="text/javascript">
  jQuery(document).ready(function(){
        jQuery("#login_wishpond").click(function(){
        var url = jQuery(this).attr('data-url');
        // alert(url);
        var isForm = jQuery(this).attr('data-form-type');
        // alert(isForm);
        var signUpForm = jQuery('.'+isForm);
          console.log('hello');
          var data = signUpForm.serialize();
          // alert(data);
          jQuery.ajax({
            method: "POST",
            url: url,
            data: data,
          }).done(function( msg ) {

            window.location = "index.php?type=q";

          });
        });
    });
</script>

  <script type="text/javascript">

  /* Login form goes here */
    // function postForm(url,isForm)
    // {
    //     alert(isForm);
    //     //jQuery('.'+isForm).show();
    //     // $('[id^=page]').hide();
    //     var signUpForm = jQuery('.'+isForm);
    //     signUpForm.submit(function(e){
    //       //alert('yes');
    //       e.preventDefault();
    //       //alert(url);
    //       console.log('hello');
    //       var data = signUpForm.serialize();
    //       jQuery.ajax({
    //         method: "POST",
    //         url: url,
    //         data: data,
    //       }).done(function( msg ) {
    //         jQuery('.wishpondLoginFrm').css('display','none');
    //         jQuery('.wishpondTrackForm').css('display','block');

    //       });
    //     });
    // }

   // jQuery(document).ready(function(){
   //      jQuery("#login_wishpond").click(function(){
   //          //alert(isForm);
   //      var url = $(this).attr('data-url');
   //      var isForm = $(this).attr('data-form-type');
   //      alert(url);
   //      //var url = 'https://www.wishpond.com/session?redirect_to=https%3A%2F%2Fwww.wishpondapps.com%2Flogin.php';
   //      //jQuery('.'+isForm).show();
   //      // $('[id^=page]').hide();
   //      var signUpForm = jQuery('.'+isForm);
   //      signUpForm.submit(function(e){
   //        //alert('yes');
   //        e.preventDefault();
   //        //alert(url);
   //        console.log('hello');
   //        var data = signUpForm.serialize();
   //        alert(data);
   //        jQuery.ajax({
   //          method: "POST",
   //          url: url,
   //          data: data,
   //        }).done(function( msg ) {
   //          jQuery('.wishpondLoginFrm').css('display','none');
   //          jQuery('.wishpondTrackForm').css('display','block');

   //        });
   //      });
   //      });
   //  });

</script>

  <script type="text/javascript">
    ShopifyApp.init({
      apiKey:"<?php echo $api_key; ?>",
      shopOrigin:"<?php echo 'https://'.$_SESSION['shop']; ?>",
      debug: true
    });
  </script>
  <script type="text/javascript">
    ShopifyApp.ready(function(){
      ShopifyApp.Bar.initialize({
        title: 'Wishpond',
        callback: function(){ 
          alert();
          ShopifyApp.Bar.loadingOff(); 
        }
      });
    });
  </script>
</body>
</html>