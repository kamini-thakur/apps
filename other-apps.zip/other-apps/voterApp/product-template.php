<?php

if(empty($ProductsArray))
	  {
	echo "No Products found";
	exit();
	  }	

	  echo '<table class="table table-bordered text-center">
				
			<tr>
				<th>Product Name </th>
				<th>Vote Count</th>
				<th>Enabled</th>
			</tr>';
			$_COUNT=0;
 foreach($ProductsArray as $key=>$value)
	{
		//////////////////////////////////
		$count=0;
		$_END_TIME=time();
		
		$_DIFF=$_END_TIME - $_START_TIME;
		//echo ceil($_DIFF)."<br>";
		if(ceil($_DIFF < 2))
		{sleep(ceil($_DIFF));}
		
      if($_COUNT==2 && $_DIFF < 2)
      {
      	sleep(1.5);
      	$_COUNT=0;
      }
	  $_VOTER_METAFIELD    ='/admin/products/'.$value['id'].'/metafields.json?namespace=voterCount';
	  $PostMetaRequest     = $sc->call('GET',$_VOTER_METAFIELD);	

	  ///////////////

	  $_VOTER_STATE    ='/admin/products/'.$value['id'].'/metafields.json?namespace=proVoterState';
      $StateMetaRequest     = $sc->call('GET',$_VOTER_STATE);	

     $str=' <input type="checkbox" class="toggleState" id="'.$value['id'].'" name="enableReviewTextOne"  title="This is my image tooltip message!" data-id='.$value['id'].'>
      <label for="'.$value['id'].'"></label>';

	  ////////////
	  $_COUNT++;

       foreach($StateMetaRequest as $key=>$val)
	          {
	          

	          	$state = $val['value'];
	          	if ($state=='on') {
	          		# code...
	          		$str=' <input type="checkbox" class="toggleState" id="'.$value['id'].'" name="enableReviewTextOne"  title="This is my image tooltip message!" checked="checked" data-id='.$value['id'].'>
      <label for="'.$value['id'].'"></label>';
	          	}
	          	}

		//////////////////////////////////

	          	foreach($PostMetaRequest as $key=>$val)
	          {
	          		$count = $val['value'];
	          	}


	    ///////////////////////////////
    echo '<tr>
				        <td><a href="#">'.$value['title'].'</td>
						<td>'.$count.'</td>
						<td>'.'<div class="slideThree">'.$str.'
     
    </div>';'
						</td>
				</tr>';
			 $_START_TIME=time();
	}

echo '</table>';
	?>