<?php
require_once 'header.php';

try
    {
    	$q='*';
    	if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
                      $pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security
                      
                  } else { // If the pn URL variable is not present force it to be value of page number 1
                      $pn = 1;
                  }
    	if (isset($_POST['q'])) {
    		# search by title...
    		$q=$_POST['q'];
    		$q=urlencode($q);
    		$ProductCount =$sc->call('GET','/admin/products/count.json?title='.$q);
         $ProductsArray=$sc->call('GET','/admin/products.json?fields=title,id&limit=10&published=true&title='.$q.'&page='.$pn);
    	}
    	elseif (isset($_POST['v'])) {
    		# filter by vendor...
    		$v=$_POST['v'];
    		$v=urlencode($v);
    		
    	 $ProductCount =$sc->call('GET','/admin/products/count.json?vendor='.$v);
         $ProductsArray=$sc->call('GET','/admin/products.json?fields=title,id&limit=10&published=true&vendor='.$v.'&page='.$pn);
    	}
    	elseif (isset($_POST['t'])) {
    		# filter by type
    		$t=$_POST['t'];
    		$t=urlencode($t);
    		
    		$ProductCount =$sc->call('GET','/admin/products/count.json?product_type='.$t);
         $ProductsArray=$sc->call('GET','/admin/products.json?fields=title,id&limit=10&published=true&product_type='.$t.'&page='.$pn);
    	}
    	elseif (isset($_POST['collect'])) {
    		// filter by collection
    		$cid=$_POST['collect'];
    		//$cid=urlencode($t);
    		$ProductCount =$sc->call('GET','/admin/products/count.json?collection_id='.$cid);
         $ProductsArray=$sc->call('GET','/admin/products.json?fields=title,id&limit=10&published=true&collection_id='.$cid.'&page='.$pn);
    		
    		# code...
    	}
      elseif (isset($_POST['toggle'])) {
      $url='/admin/metafields.json';
      $metaFieldArray = array("metafield"=>array("namespace"=>"unvote","key"=>"unvoteToggle","value"=>$_POST['val'],"value_type"=>"string"));
           var_dump($sc->call('POST',$url,$metaFieldArray));
            
      }



        ///////////////////////////////////////////////////

          $_START_TIME=time();

       ///////////////////////////////////////////////////

        
        //////////////////////////////////////////////////
        
        
         


       ///////////////////////////////////////////////////

         require_once 'product-template.php';
        
                    
    }
            catch (ShopifyApiException $e)
    {
    
         // var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         // var_dump($e->getPath());// -> path of failing request
        // var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
        // var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
    
    }
require_once 'footer.php';
?>