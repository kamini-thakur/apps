<?php
header('p3p: CP="ALL DSP COR PSAa PSDa OUR NOR ONL UNI COM NAV"');
set_time_limit(0);
ini_set("display_errors", 1);
ini_set('session.gc_maxlifetime', 36000);
session_set_cookie_params(36000);
error_reporting(E_ALL);
session_start();
require 'keys.php';
require 'shopify.php';
$threshLimit=10;
$chkStr='<input class="" id="unvoteToggle" name="unvoteVal"  type="checkbox">';
//require_once 'database_config.php';
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);

$shopMeta='/admin/metafields.json?namespace=threshold';
$shopMetarr=$sc->call('GET',$shopMeta);
foreach($shopMetarr as $key=>$val)
            {          

              $threshLimit = $val['value'];
            }

 error_reporting(E_ALL);
 $filename= basename($_SERVER['SCRIPT_FILENAME']);
$colllect_url[]= '/admin/custom_collections.json';
$colllect_url[]='/admin/smart_collections.json';

$str='';
foreach ($colllect_url as $key => $u) {
	# code...
$Custom_collect     =$sc->call('GET',$u);

foreach ($Custom_collect as $key => $value) {
$str=$str. '<option value="'.$value["id"].'">'.$value['title'].'</option>';
}
}
$voteMeta = '/admin/metafields.json?namespace=unvote';
$svoteMetarr=$sc->call('GET',$voteMeta);
foreach($svoteMetarr as $key=>$val)
    {          

      $voteState = $val['value'];
    }

if ($voteState=='toggleOn') {
  # code...
  $chkStr='<input class="" id="unvoteToggle" name="unvoteVal"  type="checkbox" checked="checked">';

}

?>

<html>
<head>
  <link rel="stylesheet" type="text/css" href="StyleQuickShop.css">
  <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>

<link rel="stylesheet"  href="https://bootswatch.com/flatly/bootstrap.min.css">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="csss/admin.css">

      <style type="text/css">


input.submit {
  background: none repeat scroll 0 0 #ffffff;
  border: 1px solid #adadad;
  border-radius: 0;
  color: #479ccf;
  padding: 3px 5px;
}
input.submit:hover {
  background: none repeat scroll 0 0 #eaeaea;
  cursor: pointer;
}
td:nth-child(1) {
    color: #2C3E50;
}
form#textSearch {
    width: 913px;
    margin-top: 17px;
}
table {
  table-layout: fixed;
}
.noticeDiv_fixed {
    position: fixed;
    bottom: -86px;
    left: 0;
    background: rgba(0,0,0,0.85);
    width: 100%;
    color: #fff;
    padding: 0 15px;
    transition: all ease 0.5s;
    -webkit-transition: all ease 0.5s;
    -moz-transition: all ease 0.5s;
    -ms-transition: all ease 0.5s;
    height: 86px;
}

/**************************************************************/

		.navbar-header form {
  float: left;
  width: 50%;
}
.form-control, input {
  background: #e9f7ff none repeat scroll 0 0;
  border: 1px solid #cccccc;
  border-radius: 5px;
  padding: 5px 200px 5px 10px;
}
.navbar-header {
  padding-top: 35px;
}
.navbar-default {
  background-color: #ffffff;
  border-color: transparent;
}
.navbar-header input, button, select, textarea {
  background: #e9f7ff none repeat scroll 0 0;
  border: 1px solid #cccccc;
  border-radius: 3px;
}
.bg-primary {
  border: medium none;
  border-radius: 5px;
  margin-left: 2px;
  padding-left: 20px;
  padding-right: 20px;
}
.navbar-header input[type="submit"].bg-primary{
	background: rgb(76,76,76); /* Old browsers */
	background: -moz-linear-gradient(top, rgba(76,76,76,1) 0%, rgba(89,89,89,1) 12%, rgba(0,0,0,1) 40%, rgba(0,0,0,1) 40%, rgba(17,17,17,1) 44%, rgba(102,102,102,1) 100%, rgba(17,17,17,1) 100%, rgba(44,44,44,1) 100%, rgba(44,44,44,1) 100%, rgba(43,43,43,1) 100%, rgba(28,28,28,1) 100%, rgba(19,19,19,1) 100%, rgba(71,71,71,1) 100%, rgba(71,71,71,1) 100%, rgba(19,19,19,1) 100%, rgba(71,71,71,1) 101%, rgba(44,44,44,1) 101%, rgba(71,71,71,1) 102%, rgba(19,19,19,1) 102%, rgba(28,28,28,1) 103%); /* FF3.6-15 */
	background: -webkit-linear-gradient(top, rgba(76,76,76,1) 0%,rgba(89,89,89,1) 12%,rgba(0,0,0,1) 40%,rgba(0,0,0,1) 40%,rgba(17,17,17,1) 44%,rgba(102,102,102,1) 100%,rgba(17,17,17,1) 100%,rgba(44,44,44,1) 100%,rgba(44,44,44,1) 100%,rgba(43,43,43,1) 100%,rgba(28,28,28,1) 100%,rgba(19,19,19,1) 100%,rgba(71,71,71,1) 100%,rgba(71,71,71,1) 100%,rgba(19,19,19,1) 100%,rgba(71,71,71,1) 101%,rgba(44,44,44,1) 101%,rgba(71,71,71,1) 102%,rgba(19,19,19,1) 102%,rgba(28,28,28,1) 103%); /* Chrome10-25,Safari5.1-6 */
	background: linear-gradient(to bottom, rgba(76,76,76,1) 0%,rgba(89,89,89,1) 12%,rgba(0,0,0,1) 40%,rgba(0,0,0,1) 40%,rgba(17,17,17,1) 44%,rgba(102,102,102,1) 100%,rgba(17,17,17,1) 100%,rgba(44,44,44,1) 100%,rgba(44,44,44,1) 100%,rgba(43,43,43,1) 100%,rgba(28,28,28,1) 100%,rgba(19,19,19,1) 100%,rgba(71,71,71,1) 100%,rgba(71,71,71,1) 100%,rgba(19,19,19,1) 100%,rgba(71,71,71,1) 101%,rgba(44,44,44,1) 101%,rgba(71,71,71,1) 102%,rgba(19,19,19,1) 102%,rgba(28,28,28,1) 103%);
	 border: none;
}
select#collectSelect {
 padding: 5px 279px 5px 5px;
}
.slideToggle {
    display: inline-block;
    margin-left: 15px;
    vertical-align: middle;
}
/*************************************************************/
</style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
  
 	  <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>


</head>

<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
       
           
              <form action="limit.php" method="POST" id="threshold">
              <input type="text" name="q" placeholder="Enter limit" id="threshold-text" value="<?php echo $threshLimit; ?>">
              <input type="hidden" name="token" value="00efa988ee2122fbbcd" id="thrs-token">
              <input type="submit" name="" value="GO" class="bg-primary">
              </form>
<form action="txt-search.php" method="POST" >
              <input type="text" name="q" placeholder="Enter search term">
              <input type="hidden" name="token" value="00efa988ee2122fbbcd" id="thrs-token">
              <input type="submit" name="" value="GO" class="bg-primary">
              </form>
<form action="txt-search.php" method="POST" >
              <input type="text" name="v" placeholder="Enter Vendor name">
              <input type="hidden" name="token" value="00efa988ee2122fbbcd" id="thrs-token">
              <input type="submit" name="" value="GO" class="bg-primary">
              </form>

              <form action="txt-search.php" method="POST" >
              <input type="text" name="t" placeholder="Enter Product Type">
              <input type="hidden" name="token" value="00efa988ee2122fbbcd" id="thrs-token">
              <input type="submit" name="" value="GO" class="bg-primary">
              </form>
              <form action="txt-search.php" method="POST" >
              <select name="collect" id="collectSelect">
              	
<?php 

echo $str;

?>

              </select>
               <input type="submit" name="" value="GO" class="bg-primary">
              </form>
              <form>
                
                <label>Toggle Unvote</label>  <div class="slideToggle slideThree"> 


          <?php

          echo $chkStr;
          ?>
      <label for="unvoteToggle"></label>
     
    </div>

              </form>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li 
        
      </ul>
      
      
    </div><!-- /.navbar-collapse -->
      
  </div>
    
</nav>

