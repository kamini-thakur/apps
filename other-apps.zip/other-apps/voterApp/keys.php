<?php
$api_key = '83a058ade70132b4cd029b02d111408f';
$secret = '3f4e68877e1305f1799de58e2ff55bfe';

?>