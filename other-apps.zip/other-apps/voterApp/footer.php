 <?php

 echo '<div class="noticeDiv_fixed">
  <div class="tableDiv">
  <div class="tableCellDiv">
<h3 align="center">Settings Saved Successfully</h3>
  </div>
</div>
</div>';
?>
   

 <script type="text/javascript">
    
$(document).ready(function(){
//////////////////////////////




$("#unvoteToggle:checkbox").change(function(){
  var i='toggleOff';
  var o =$(this);
  if(o.is(':checked'))
                 {
                   i='toggleOn';
                 }

var d={val:i,toggle:'act'};

/////////////////////////////
    
sendRequest('txt-search.php',d);



  });






///////////////////////////////

$(".toggleState:checkbox").change(function(){
  var i='off';
  var o =$(this);
  if(o.is(':checked'))
                 {
                   i='on';
                 }
var pid=$(this).attr('id');
var d={pid:pid,state:i};

/////////////////////////////
    
sendRequest('toggleProductState.php',d);



  });


$('form#threshold').submit(function(e){

        e.preventDefault();
        var v=$('#threshold-text').val();
        var t=$('#thrs-token').val();
        var d={v:v,token:t};
        sendRequest('toggleProductState.php',d);
});


        function sendRequest(url,data)
          {
            $.ajax({
                      url: url,
                      dataType: 'text',
                      type: 'post',
                      data: data,
                      success: function(m) {
                        // Re-enable add to cart button.
                      // console.log(d);
                       $('.noticeDiv_fixed').css("bottom",'0');
                        setTimeout(function(){ $('.noticeDiv_fixed').css("bottom",'-86px'); }, 2000);
                     

                      }, 
                      error: function(XMLHttpRequest) {
                        var response = eval('(' + XMLHttpRequest.responseText + ')');

                        response = response.description;
                        alert(response);

                      }
                   });
          }

});



  </script>