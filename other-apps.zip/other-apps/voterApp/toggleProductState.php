<?php
session_start();
header('p3p: CP="ALL DSP COR PSAa PSDa OUR NOR ONL UNI COM NAV"');
set_time_limit(0);
ini_set("display_errors", 1);
ini_set('session.gc_maxlifetime', 36000);
session_set_cookie_params(36000);
error_reporting(E_ALL);
require 'keys.php';
require 'shopify.php';
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
if(isset($_POST['token']))
	 {
	 	$val=$_POST['v'];
	 	storeMetafield($val);
	 }
	 else
	 {
$id=$_POST['pid'];
$state=$_POST['state'];
createMetafield($state);
}
function createMetafield($value)

{

/***************************/

////////////// $meta = array("metafield"=>array("namespace"=>"qwerty","key"=>"thakur","value"=>$value,"value_type"=>"string"))
global $sc,$id;
$url='/admin/products/'.$id.'/metafields.json';

            

 $metaFieldArray = array("metafield"=>array("namespace"=>"proVoterState","key"=>"advoterState","value"=>$value,"value_type"=>"string"));
                
            if($sc->call('POST',$url,$metaFieldArray))
            {
            	echo true;
            	die;
            }
            


/****************************/



}

function storeMetafield($v)
  {
  	global $sc;
  	//$v=(int)$v;
$url='/admin/metafields.json';

            

 $metaFieldArray = array("metafield"=>array("namespace"=>"threshold","key"=>"vote-limit","value"=>$v,"value_type"=>"integer"));
                
            $arr=($sc->call('POST',$url,$metaFieldArray));
            {
            	if(isset($arr['id'])){
            	echo true;
            	die;
            }
            }
  }


?>