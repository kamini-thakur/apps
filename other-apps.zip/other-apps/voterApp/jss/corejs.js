 "use strict";
 (function() {
   var productTitle='';
   var productImage='';
     var cartPopUp = {

         version: "1.0",
         settings: {},
       
         initiate: function() {

             if (this.isUrl()) {
               this.loadCss();
               this.loadAnotherCss();
                 this.getProductId(cartPopUp);
                 //this.createOrderForm();
                 //this.loadSettings();
             }
         },
          loadCss:function loadCss() {
             var head = document.getElementsByTagName('head')[0],
             link = document.createElement('link');
             link.type = 'text/css';
             link.rel = 'stylesheet';
             link.href = 'https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css';
             head.appendChild(link);
             console.log(link);
           },
       loadAnotherCss:function()
       {
         var head = document.getElementsByTagName('head')[0],
             link = document.createElement('link');
             link.type = 'text/css';
             link.rel = 'stylesheet';
             link.href = 'https://cdn.shopify.com/s/files/1/0789/9925/files/cart.css?12643397362679906397';
             head.appendChild(link);
             console.log(link);
         
       },
         isUrl: function() {
             var urlPath = document.URL.split('/');
             var referrerPath=document.referrer.split('/');
             console.log('getting page url');
             console.log(urlPath[3]);
             if (urlPath[3] === 'cart' && referrerPath[3]!=='cart' ) {
                console.log('getting page iiiiii');
                 return true;
             } else {
                 return false;
             }
         },
           
           loadAlertBox: function(productId,title,image,obj) {
           console.log(productId);
           productTitle       =title;
           productImage       =ElCart.popUpImage;
           var reviewOne      =ElCart.ReviewOne;
           var reviewOneStars =parseInt(reviewOne.substring(0, 3)[2]);
           if(reviewOne.length > 3)
           {
           var rOnehtml       = obj.cartHtml(reviewOne.substring(4,reviewOne.length),reviewOneStars);
         }
         else
         {
          var rOnehtml='';
         }
           //alert(reviewOneStars[2]);
           var reviewTwo      =ElCart.ReviewTwo;
           var reviewTwoStars = parseInt(reviewTwo.substring(0,3)[2]);
           if (reviewTwo.length > 3) {
           var rTwohtml       = obj.cartHtml(reviewTwo.substring(4,reviewTwo.length),reviewTwoStars);
         }
         else{
          var rTwohtml='';
         }
           //alert(reviewTwoStars[2]);
           var reviewThr      =ElCart.ReviewThr;
           var reviewThrStars =parseInt(reviewThr.substring(0,3)[2]);

           if (reviewThr.length > 3) {
           var rThrhtml       = obj.cartHtml(reviewThr.substring(4,reviewThr.length),reviewThrStars);}
           else{
            var rThrhtml='';
           }
           var Starmsg=rThrhtml+rTwohtml+rOnehtml;
           /*
var Msghtml='';
                Msghtml+='<div class="elcart-starrating-main">';
      Msghtml+='<div  class="elcart-review elcart-clickable"><div>';
     //===================================================================
      Msghtml+='<div class="elcart-review-star-rating">';
      Msghtml+='<ul class="elcart-rating">';
       if(is_int($count) && $count > 0)
         {
          for($i=0;$i<$count;$i++)
          $html+='<li>';
        }
        else
        {
      Msghtml+='<li></li><li></li><li></li><li></li>';
        }
      Msghtml+='</ul>';
      Msghtml+='</div>';
    //=====================================================================
      Msghtml+='<div class="elcart-quoted-review"><span class="review-title">'+$finalString+' </span></div>';
      Msghtml+='</div> </div></div>';


*/

           ///////////////////////////////////////////
           
           $.ajax({
                  method: "POST",
                  url: "/apps/cartReviews",
                  data: { id: productId }
                  })
                    .done(function( msg ) {
    //alert( "Data Saved: " + msg );
            console.log(msg);
            $('body').prepend('<div id="elcartreview" class="elcart "></div>');
            if(msg.trim()!='Nothing')
            {
              productImage=msg;
            }
            ///////////////////////////////////////////////////////
var html='<div id="elcartreview" class="elcart "><div class="elcart-overlay"></div><div class="elcart-dialog"><div class="elcart-content"><div class="elcart-header"><h4 class="elcart-title">'+ti+'</h4> </div>';
            
html+='<div class="elcart-body"><div class="elcart-image"><img src="'+productImage+'"></div><div class="elcart-text">';
          
html+=Starmsg+'</div>';

html+='<div class="elcart-footer"><button type="button" class="elcartDismissButton btn btn-primary" style="background-color:'+c+';color:'+bt+'px ;max-width:100%">'+t+'</button></div></div></div>';
            
            
            
            /////////////////////////////////////////////////////////////
            

             $('#elcartreview').append(html);
             obj.hidemyAss(obj);
 });
         },
         cartHtml: function(msg,starCount)
          {
           
            var i='';
            var Msghtml='';
                Msghtml+='<div class="elcart-starrating-main">';
           Msghtml+='<div  class="elcart-review elcart-clickable"><div>';
     //===================================================================
           Msghtml+='<div class="elcart-review-star-rating">';
          Msghtml+='<ul class="elcart-rating">';
           if(parseInt(starCount) && parseInt(starCount) > 0)
             {
              for(i=0;i<parseInt(starCount);i++)
              Msghtml+='<li>';
            }
            else
            {
          Msghtml+='<li></li><li></li><li></li><li></li>';
               }
           Msghtml+='</ul>';
           Msghtml+='</div>';
    //=====================================================================
          Msghtml+='<div class="elcart-quoted-review"><span class="review-title">'+msg+' </span></div>';
          Msghtml+='</div> </div></div>';
          return Msghtml;
          },

         getProductId: function(obj) {
             $.getJSON('/cart.js').done(function(result) {
                 console.log(result.item_count);
                 var productId = result.items[0].product_id;
                 var title     = result.items[0].title;
                 var image     =ElCart.popUpImage;
                 obj.loadAlertBox(productId,title,image,obj);
             });
         },
       hidemyAss:function(obj)
       {
         //to add event listener to table
var el = document.getElementsByClassName("btn-primary")[0];
el.addEventListener("click", function(){obj.hideButton()}, false);
       },
       
  hideButton: function(new_text) {
            document.getElementById('elcartreview').style.display='none';
     }
     }    
if(ElCart.IsVisible.trim()=='enable')
{
      var t=ElCart.BtnText.trim();
      var c=ElCart.BtnColor.trim();
      var bt=ElCart.BtnTxtColor.trim();
      var bw=parseInt(ElCart.btnWidth.trim());
      var ti=ElCart.cartTitle.trim();
      var isrc=ElCart.popUpImage;
     if (window.attachEvent)
         window.attachEvent('onload', cartPopUp.initiate());
     else {
         window.addEventListener('load', cartPopUp.initiate(), false);
     }
}


 })();