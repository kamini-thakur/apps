<?php
require_once 'header.php';
//var_dump($sc);
$_Company_name    ='';
$_Order_threshold ='';
$_Rate_Abv_Ord   ='';
$_Rate_Blw_Ord    ='';
$shopURL='https://'.$_SESSION['shop'];
try
    {

        ///////////////////////////////////////////////////

          $_START_TIME=time();

       ///////////////////////////////////////////////////

        if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
                      $pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security
                      
                  } else { // If the pn URL variable is not present force it to be value of page number 1
                      $pn = 1;
                  }
        //////////////////////////////////////////////////
        
        
         $ProductCount =$sc->call('GET','/admin/products/count.json');
         $ProductsArray=$sc->call('GET','/admin/products.json?fields=title,id&limit=80&&published=true&page='.$pn);


       ///////////////////////////////////////////////////

         require_once 'product-template.php';
        
                    
    }
            catch (ShopifyApiException $e)
    {
    
         // var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         // var_dump($e->getPath());// -> path of failing request
        // var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
        // var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
    
    }
    require_once 'footer.php';
?>

 
 <script type="text/javascript">
    ShopifyApp.init({
      apiKey: '<?php echo $api_key; ?>',
      shopOrigin:"<?php echo $shopURL; ?>",

      debug: true
    });
    </script>
   <script type="text/javascript">
  ShopifyApp.ready(function(){
    ShopifyApp.Bar.initialize({
      
      title: 'ADMIN',
      
          
          callback: function(){ 
            ShopifyApp.Bar.loadingOff();
            
          }
       
      
    });
  });
  </script>
  
    
    </body>
</html>