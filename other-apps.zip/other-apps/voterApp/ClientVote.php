<?php
require 'keys.php';
require 'shopify.php';
$token='99f1161553bb865088abbad221379df7';
//echo json_encode($_POST);
 $id=$_POST['pid'];
 $customerId=$_POST['cid'];
 $_m=$_POST['m'];
 $reponseArr=[];

$_HEADERS = apache_request_headers();
//var_dump($_HEADERS);
$_DOMAIN  =$_HEADERS['X-Forwarded-Host'];
$sc = new ShopifyClient($_DOMAIN, $token, $api_key, $secret);

//createMetafield();

////* Check if a customer has already voted *////
if($_m=='add')
{
$custArray=getCustomerMeta();
$strToSend=checkIfVoted($custArray[0]['value']);
if($strToSend)
 {
  echo $reponseArr="Already Voted";
  die;
 }
}

////* End of check *////




$arr=getVoterCount();

if(empty($arr))
    {
        if($_m==='add')
        {
        createMetafield(1);
        }
    }
else
    {
        if($_m==='add')
        {
         $value=$arr[0]['value'] + 1;    
         }
        elseif ($_m==='sub') {
          # code...
            if($arr[0]['value'] > 0)
            {
            $value=$arr[0]['value']-1;
             }
        }
     $metaSuccess= createMetafield($value);
    }
if($metaSuccess)
{
$custArray=getCustomerMeta();
}
else
{
    die;
}


if(empty($custArray))
    {
         if($_m==='add')
         {
        addVotesToCustomer($id);
         }
    }
else
    {
      if($_m==='add')
         {
        $custArray=$custArray[0]['value'].','.$id;
         }
         elseif($_m==='sub')
         {
           $custArray= newSubArray($custArray[0]['value']);
         }
        addVotesToCustomer($custArray);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function getCustomerMeta()
  {
  	global $customerId,$sc,$id;

    $url='/admin/customers/'.$customerId.'/metafields.json?namespace=CustvoterCount';
    $array=$sc->call('GET',$url);
    return $array;

        

  }

////////////////////////////////////////////////////////////////////////////////////////////////////////////

function getVoterCount()


{
	global $id,$sc;

    $url='/admin/products/'.$id.'/metafields.json?namespace=voterCount';
    $array=$sc->call('GET',$url);
    return $array;

}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////

function addVotesToCustomer($value)

 {
 		global $customerId,$sc,$id,$_m;
 	    $url='/admin/customers/'.$customerId.'/metafields.json';

        $metaFieldArray = array("metafield"=>array("namespace"=>"CustvoterCount","key"=>"CustAdvoter","value"=>$value,"value_type"=>"string"));
                
            if($sc->call('POST',$url,$metaFieldArray))
            {
              if($_m==='add')
               {
                  	echo 'voted';
                } 
              elseif($_m==='sub')
                {
                  echo 'unvote';
                } 	
            }

 }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

function createMetafield($value)

{

/***************************/

global $sc,$id;
$url='/admin/products/'.$id.'/metafields.json';
 $metaFieldArray = array("metafield"=>array("namespace"=>"voterCount","key"=>"advoter","value"=>$value,"value_type"=>"integer"));
                
            if($sc->call('POST',$url,$metaFieldArray))
            {
            	return true;
            }
        return false;
        }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function newSubArray($str)
           {
            // @params ; String
            // @value  : String
            // returns new string after removing the ID of product from customer metafield
            // Used for unvote functionality
            global $id;
            $array=explode(',', $str);
            
           $pos=array_search($id, $array);
            $newArr=array_splice($array, $pos,1);
            $returnStr= implode(',',$array);
            return $returnStr;


           }

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function checkIfVoted($str)
            {
              global $id;
              $array=explode(',', $str);
              if (in_array($id, $array)) {
                # code...
                return true;
              }
              return false;
            }

?>