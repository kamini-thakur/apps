<?php

header('Location: /fashioncircle/login.php');

?>