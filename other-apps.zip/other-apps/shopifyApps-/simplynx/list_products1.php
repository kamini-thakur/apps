<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'header.php';
require 'shopify.php';
require 'keys.php';
require 'database_config.php';

$shopDomain="scindedawk.myshopify.com";

$sql="SELECT * from check_status where shopDomain='".$shopDomain."' ";
$qex=mysqli_query($newCon,$sql);
$res = mysqli_fetch_array($qex);
$shopToken = $res['shopToken'];

$sc = new ShopifyClient($shopDomain, $shopToken, $api_key, $secret);

try
{
  //////// Get count of total products //////////
    
    echo '<div class="successMsg alert alert-success" style="display:none;">';
    echo 'Product syncing is on progress.It will take around 30 mins. An email will be sent to you shortly';
    echo '</div>';

  	echo '<button class="btn btn-success btn-lg" type="button" id="update_database">Sync Database</button>';

    echo '<div id="testA"></div>';
    echo '<div id="paging_here"></div>';

}
catch (ShopifyApiException $e)
{
    
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
    
}


?>

<style type="text/css">
#update_database {
    border-radius: 0;
    float: right;
    height: auto;
    margin: 8px;
}
  .info{
    width:100px;
    text-align: center;
    font-weight:bold;
    float:right;
    background-color:#444;
    color:white;
    border-radius:3px;
}
</style>
<script type="text/javascript">

webix.ready(function(){
			grid = webix.ui({
				container:"testA",
				view:"datatable",

        columns:[
          { id:"id", header:"#", css:{"text-align":"center"}, width:70 },
          { id:"title", header:"Title",      width:300 },
          { id:"type", header:"Type",   width:150 },
          { id:"price",  header:"Price" ,     width:80  },
          { id:"quantity",  header:"Quantity",  width:70  },
          { id:"sku", header:"SKU",      width:100 },
          { id:"weight", header:"Weight",   width:80 },
          { id:"issuer",  header:"Issuer" ,     width:120  },
          { id:"theme",  header:"Theme",  width:100  },
          { id:"tag_date", header:"Date",      width:100 },
          { id:"tag_number", header:"Number",   width:80 },
          { id:"tag_condition",  header:"Condition" ,     width:80  }
        ],
        on:{
            onBeforeLoad:function(){
                this.showOverlay("Loading...");
            },
            onAfterLoad:function(){
                this.hideOverlay();
            }
        },
				type:{template:"{common.space()}"},
        select:"row",
        navigation:true,
        datafetch:100,//default
        loadahead:15,
        datathrottle:5,

        pager:{
          template:"{common.prev()} {common.pages()} {common.next()}",
          container:"paging_here",
          size:100,
          group:5
        },
				autoheight:true,
				autowidth:true,
        url:"data.php"
			});
			
		});

</script>
<script src='https://cdn.ravenjs.com/3.10.0/raven.min.js'></script>
<script type="text/javascript">
    
$(document).ready(function(){

        $(document).on('click','#update_database',function(e){
          alert('sync start');
           //e.preventDefault();

            $.ajax({
              type: "POST",
              url: "database_insert.php",
              data: { domain : "<?php echo $shopDomain; ?>", token : "<?php echo $shopToken ?>" },
              success: function(response)
              {
                    console.log('products saved successfully');
                    $('.successMsg').show();
                    setTimeout(function(){ $('.successMsg').css('display','none'); }, 5000);
              }
            });
           // $('.success').html(mailMsg);
        });
});
</script>