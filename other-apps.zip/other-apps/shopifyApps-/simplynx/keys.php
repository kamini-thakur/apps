<?php

$api_key = "73bba9ce50cf8c5777028dfa499dde8d";
$secret = "8350362c98b8dc78374bfd4042f2b9cf";

$baseURL = 'https://www.simplynx.com/simplynx';

?>