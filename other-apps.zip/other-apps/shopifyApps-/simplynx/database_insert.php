<?php 
require 'header.php';
require 'shopify.php';
require 'keys.php';
require 'database_config.php';


if(isset($_POST['domain']))
{
	////////////// Get all products of a shop /////////

	$domain = $_POST['domain'];
	$token = $_POST['token'];
    $timestamp = date("Y-m-d_H:i:s");

    ////////// Save entry in database /////////////
    $sql="INSERT INTO check_status(shopDomain,shopToken,exec_status,final_status,entry_date)VALUES('".$domain."','".$token."',0,0,'".$timestamp."')";
    $qex=mysqli_query($newCon,$sql);
    if ($qex) {
    	echo "Success";
    }
    else {
    	echo "error";
    }
    return "Success"; 
}

?>