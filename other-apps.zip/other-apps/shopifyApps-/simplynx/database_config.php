<?php
 
// require_once("connector/data_connector.php");
// require_once("connector/db_mysqli.php");

// $_HOST     = 'localhost';
// $_USER_NAME= 'scindedawk';
// $_PASSWORD = 'vsI0aVf8a_5K';
// $_DATABASE = 'scindedawk';
// $dbtype = "MySQLi";
// $newCon=mysqli_connect($_HOST, $_USER_NAME,$_PASSWORD,$_DATABASE);
// if(mysqli_connect_errno())
// {
// 	echo "connection failed";
// }

error_reporting(E_ALL);
ini_set('display_errors', 1);
// connect to mongodb
   // $m = new MongoClient("mongodb://mylivecode.com:25994");
	
	$m = new MongoClient("mongodb://sonu179208:Password123@ds125994.mlab.com:25994/mylivecode");
   echo "Connection to database successfully";
   // select a database
 //   $db = $m->mylivecode;
	// if ($db) 
	// {
	// 	echo "Database mydb selected";
	// }
	// else
	// {
	// 	echo "Database mydb not selected";
	// }

	// $collection = $db->createCollection("products");
	// if ($collection) {
	// 	echo "collection created";
	// }
	// else
	// {
	// 	echo "collection not created";
	// }
 //   	echo "Collection created succsessfully";
 
?>