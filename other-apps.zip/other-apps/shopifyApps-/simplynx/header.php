<?php
header('p3p: CP="ALL DSP COR PSAa PSDa OUR NOR ONL UNI COM NAV"');
ob_start();
session_start();
set_time_limit(0);
// ini_set("display_errors", 1);
ini_set('session.gc_maxlifetime', 36000);
session_set_cookie_params(36000);
// error_reporting(E_ALL);
?>
<html>
<head>
  <title>SHOPIFY APP</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
  <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>

  <script src='https://cdn.ravenjs.com/3.10.0/raven.min.js'></script>

  <!-- Bootstrap JS is not required, but included for the responsive demo navigation -->
  <!-- <link rel="stylesheet" type="text/css" href="connector/samples.css"> -->
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

  <script src="includes/webix.js" type="text/javascript" charset="utf-8"></script>
  <link rel="stylesheet" href="includes/webix.css" type="text/css" charset="utf-8">

</head>
