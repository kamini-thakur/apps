<?php
ini_set("display_errors", 1);
error_reporting(E_ALL);
ob_start();
session_start();
require_once 'keys.php';
define('SHOPIFY_API_KEY', $api_key);
define('SHOPIFY_SECRET',  $secret);
define('SHOPIFY_SCOPE', 'read_products,write_products,read_themes,write_themes,read_orders,write_orders,read_customers,write_customers');

    require 'shopify.php';
    if (isset($_GET['code'])) { // if the code param has been sent to this page... we are in Step 2
        // Step 2: do a form POST to get the access token
        $shopifyClient = new ShopifyClient($_GET['shop'], "", SHOPIFY_API_KEY, SHOPIFY_SECRET);
        session_unset();

        // Now, request the token and store it in your session.
        $_SESSION['token'] = $shopifyClient->getAccessToken($_GET['code']);
        $accessToken=$_SESSION['token'];
        $shopURL= $_GET['shop'];
        if ($_SESSION['token'] != '')
            $_SESSION['shop'] = $_GET['shop'];
        $shopURL='https://'.$_SESSION['shop']; ?>
         <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
  
        <script type="text/javascript">
    ShopifyApp.init({
      apiKey: '<?php echo $api_key; ?>',
      shopOrigin:"<?php echo $shopURL; ?>",    
      debug: true
    });

    ShopifyApp.Modal.open({
  src: 'index.php',
  title: 'Simplynx'
  width: 'large',
  height: 500,
  buttons: {
    
}
  });
  </script>
<?php        
header("Location:index.php");
        exit;       
    }
    // if they posted the form with the shop name
    else if (isset($_POST['shop']) || isset($_GET['shop'])) {

  
        // Step 1: get the shopname from the user and redirect the user to the
        // shopify authorization page where they can choose to authorize this app
        $shop = isset($_POST['shop']) ? $_POST['shop'] : $_GET['shop'];
        $shopifyClient = new ShopifyClient($shop, "", SHOPIFY_API_KEY, SHOPIFY_SECRET);

        // get the URL to the current page
        $pageURL = 'http';
        if ($_SERVER["HTTPS"] == "on") { $pageURL .= "s"; }
        $pageURL .= "://";
        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
        } else {
            $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
        }

        // redirect to authorize url
        header("Location: " . $shopifyClient->getAuthorizeUrl(SHOPIFY_SCOPE, $pageURL));
        exit;
    }

    // first time to the page, show the form below
?>
<!DOCTYPE html>
<html>
<head>
  <title>SHOPIFY APP</title>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="includes/login-style.css">

  <style type="text/css">
    #shopifyAPP{

      background:url('http://strategistmagazine.co/wp-content/uploads/2015/04/shopify-logo.jpg') no-repeat center fixed;
      background-size: cover;
    }

  </style>
</head>
<body id="shopifyAPP">

<div class="loging-page">
  <div class="login-page">
    <h1>Install this app in a shop to get access to its private admin data.</h1> 

    <p class="subtitle"><span class="hint">Don&rsquo;t have a shop to install your app in handy?</span> <a href="https://app.shopify.com/services/partners/api_clients/test_shops">Create a test shop.</a></p> 

    <form action="" method="post" class="install-app-form">
      <label for="shop"><strong>The URL of the Shop</strong> 
        <span class="hint">(enter it exactly like this: myshop.myshopify.com)</span> 
      </label> 
      <div class="input-group"> 
        <input id="shop" name="shop" size="45" type="text" value="" placeholder="enter it exactly like this: myshop.myshopify.com" />
        <span class="input-group-addon"><input name="commit" type="submit" value="Install" /></span>
      </div> 
    </form>
  </div>
</div>

</body>
</html>
    
