<?php
require_once 'header.php';
require 'shopify.php';
require 'keys.php';
require 'database_config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);
print_r($sc);
//////////Create Webhooks as well as check it///////////

$url ='/admin/webhooks.json';

// $array=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/uninstall.php');
//       $meta=array
//             (
//                 "webhook"=>array 
//                 (
//                     "topic"=> "app/uninstalled",
//                     "address"=> $baseURL."/uninstall.php",
//                     "format"=>"json"
//                 )
//             );
    
//       if (empty($array)) {
           
//           $sc->call('POST', $url,$meta);
//       }
/////////////////////////////////////////

///////////// Create order/placed webhook ////////////
// $orderCreateArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/orderCreate.php');
//       $meta=array
//             (
//                 "webhook"=>array 
//                 (
//                     "topic"=> "orders/create",
//                     "address"=> $baseURL."/orderCreate.php",
//                     "format"=>"json"
//                 )
//             );
    
//       if (empty($orderCreateArray)) {
           
//           $sc->call('POST', $url,$meta);
//       }
/////////////////////////////////////////

///////////// Create customer/create webhook ////////////
// $customerCreateArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/customerCreate.php');
//       $meta=array
//             (
//                 "webhook"=>array 
//                 (
//                     "topic"=> "customers/create",
//                     "address"=> $baseURL."/customerCreate.php",
//                     "format"=>"json"
//                 )
//             );
    
//       if (empty($customerCreateArray)) {
           
//           $sc->call('POST', $url,$meta);
//       }
/////////////////////////////////////////

echo "app installed";

////////// Insert details into database ///////////
// $sql="SELECT * from ProductsApp where shopDomain='".$_SESSION['shop']."' ";
// $qex=mysqli_query($newCon,$sql);
// $num_rows=mysqli_num_rows($qex);
            
// if($num_rows==0)
// { 
//     $sql="INSERT INTO ProductsApp(shopDomain,shopToken)VALUES('".$_SESSION['shop']."','".$_SESSION['token']."')";
//     $qex=mysqli_query($newCon,$sql); 
// }

?>
<body>

</body>
</html>

 <script type="text/javascript">
    // ShopifyApp.init({
    //   apiKey: '<?php echo $api_key; ?>',
    //   shopOrigin:"<?php echo $shopURL; ?>",

    //   debug: true
    // });
</script>
<script type="text/javascript">

/*
  ShopifyApp.ready(function(){
    ShopifyApp.Bar.initialize({
      
      title: 'Product Import/Export',
      
          
          callback: function(){ 
            ShopifyApp.Bar.loadingOff();
            
          }
       
      
    });
  }); */

</script>

