<?php
	require_once("database_config.php");

	$data = new JSONDataConnector($newCon, $dbtype);
	$data->dynamic_loading(30);
	$data->render_table("product_details","id","id, title, type, price, quantity, sku, weight, issuer, theme, tag_date, tag_number, tag_condition");

?>
