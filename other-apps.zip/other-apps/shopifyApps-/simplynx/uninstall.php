<?php

require 'keys.php';
require 'database_config.php';

$data     =(file_get_contents('php://input'));
$fh       =fopen('uninstall.txt', 'w')  or die("Utyftyftf");;
//var_dump($fh);
//fwrite($fh, $data); 

$Array    =json_decode($data);

/* GET DOMAIN FROM HEDAERS  */
$_HEADERS = apache_request_headers();
$_DOMAIN  =$_HEADERS['X-Shopify-Shop-Domain'];

$delete_record = "DELETE FROM ProductsApp where shopDomain='$_DOMAIN' ";
$qex=mysqli_query($newCon,$delete_record);



?>