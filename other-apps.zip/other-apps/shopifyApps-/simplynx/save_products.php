<?php

require_once 'header.php';
require 'shopify.php';
require 'keys.php';
require 'database_config.php';
// require("includes/class.phpmailer.php");
// require("includes/class.smtp.php");

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "file her";

echo $sql="SELECT * from check_status where exec_status=0 and final_status=0 ";
$qex=mysqli_query($newCon,$sql);
if ($qex) {
    echo "success";
}
else
{
    echo "eror";
}

while($res=mysqli_fetch_array($qex))
{
    echo 'in loop';
    echo $id = $res['id'];

    $update_exec_status="UPDATE check_status set exec_status='1' where id='".$id."' ";
    $qex=mysqli_query($newCon,$update_exec_status);

    $sc = new ShopifyClient($res['shopDomain'], $res['shopToken'], $api_key, $secret);
    print_r($sc);

	echo $total_products = $sc->call('GET', '/admin/products/count.json');
    $products_per_page = 250; 
    echo $total_pages = ceil($total_products / $products_per_page); 

    for ($cur_page=1; $cur_page <= $total_pages; ++$cur_page) { 

                $product_request_url='/admin/products.json?limit='.$products_per_page.'&page='.$cur_page;
                $products_data=$sc->call('GET',$product_request_url);
                  
                foreach ($products_data as $key => $value) {

                    $product_id= $value['variants'][0]['product_id']; 

                    $title = $value['title']; 
                    $body= $value['body_html'];
                    $type= $value['product_type'];
                    $price= $value['variants'][0]['price']; 
                    $quantity= $value['variants'][0]['inventory_quantity'];
                    $image = $value['image']['src'];
                    $sku = $value['variants'][0]['sku']; 
                    $weight =  $value['variants'][0]['weight'];

                    ////// Code to split the tags /////
                   echo $tags=$value['tags'];
                    $tags = str_replace("'", "", $tags);
                    $tagsArray = explode(", ",$tags);
                    $result=array();
                    for ($i=0; $i < count($tagsArray) ; $i++) { 
                        list($k, $v) = explode('=', $tagsArray[$i]);
                        $result[ $k ] = $v;
                    }
                    print_r($result);

                    $issuer = isset($result['ISSUER']) ? $result['ISSUER'] : " ";
                    $theme = isset($result['THEME']) ? $result['THEME'] : " ";
                    $date = isset($result['DATE']) ? $result['DATE'] : " ";
                    $number = isset($result['NUMBER']) ? $result['NUMBER'] : " ";
                    $condition = isset($result['CONDITION']) ? $result['CONDITION'] : " ";

                    ////////// Insert details into database ///////////
                    $sql="SELECT * from product_details where product_id='".$product_id."' ";
                    $qex=mysqli_query($newCon,$sql);
                    $num_rows=mysqli_num_rows($qex);
                                
                    if($num_rows==0)
                    {
                       echo $sql="INSERT INTO product_details(product_id,title,body,type,price,quantity,image,sku,weight,issuer,theme,tag_date,tag_number,tag_condition)VALUES('".$product_id."','".$title."','".$body."','".$type."','".$price."','".$quantity."','".$image."','".$sku."','".$weight."','".$issuer."','".$theme."','".$date."','".$number."','".$condition."')";
        				$qex=mysqli_query($newCon,$sql); 

                        
                    }
                    else
                    {
                        echo $sql="UPDATE product_details set title='".$title."',body='".$body."',type='".$type."',price='".$price."',quantity='".$quantity."',image='".$image."',sku='".$sku."',weight='".$weight."',issuer='".$issuer."',theme='".$theme."',tag_date='".$date."',tag_number='".$number."',tag_condition='".$condition."' WHERE product_id='".$product_id."' ";

                        // $sql="INSERT INTO product_details(product_id,title,body,type,price,quantity,image,sku,weight,issuer,theme,tag_date,tag_number,condition)VALUES('".$product_id."','".$title."','".$body."','".$type."','".$price."','".$quantity."','".$image."','".$sku."','".$weight."','".$issuer."','".$theme."','".$tag_date."','".$tag_number."','".$condition."')";
                        $qex=mysqli_query($newCon,$sql);
                    }
                } /////// End of forloop
    } /////// End of forloop

    echo $total_orders = $sc->call('GET', '/admin/orders/count.json');
    $orders_per_page = 250; 
    echo $total_pages = ceil($total_orders / $orders_per_page); 

    for ($cur_page=1; $cur_page <= $total_pages; ++$cur_page) { 

                $order_request_url='/admin/orders.json?limit='.$orders_per_page.'&page='.$cur_page;
                $orders_data=$sc->call('GET',$order_request_url);
    }
   
    $update_exec_status="UPDATE check_status set final_status='1' where id='".$id."' ";
    $qex=mysqli_query($newCon,$update_exec_status);

}////////// End of while loop

function sendSuccessEmail($to)
{
   $from = "admin@simplynx.com";
   $baseURL = 'https://www.simplynx.com';
   $link = $baseURL . '/simplynx/list_products.php';
   
   $subject = "Product are saved successfully";
   $message = "Hello,<br>Please click following link to check all shop products.<br><a href='".$link."' target='_blank'>Here</a><br>Thanks";

   sendEmail($from, $to, $subject, $message);
}

sendSuccessEmail('kamini.thakur1810@esferasoft.com');

?>