<?php

require 'keys.php';
require 'shopify.php';

$domain = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];

 header('Content-Type:application/json');

 $data =file_get_contents('php://input');

//$data = '{"id":4419111109,"email":"kamini_thakur@esferasoft.com","closed_at":null,"created_at":"2017-04-05T02:01:55-04:00","updated_at":"2017-04-05T02:01:55-04:00","number":42,"note":null,"token":"8ed4cd94a22a681d8701de8f0f6a2e36","gateway":"Cash on Delivery (COD)","test":false,"total_price":"1318.61","subtotal_price":"499.00","total_weight":0,"total_tax":"62.38","taxes_included":false,"currency":"INR","financial_status":"pending","confirmed":true,"total_discounts":"0.00","total_line_items_price":"499.00","cart_token":"c3001a888c6947c486c13f7e12cb3f56","buyer_accepts_marketing":false,"name":"#1042","referring_site":"","landing_site":"\/admin\/auth\/login","cancelled_at":null,"cancel_reason":null,"total_price_usd":"20.32","checkout_token":"5f4411d8cd42c8db5b8d1293c9050ee0","reference":null,"user_id":null,"location_id":null,"source_identifier":null,"source_url":null,"processed_at":"2017-04-05T02:01:55-04:00","device_id":null,"browser_ip":null,"landing_site_ref":null,"order_number":1042,"discount_codes":[],"note_attributes":[],"payment_gateway_names":["Cash on Delivery (COD)"],"processing_method":"manual","checkout_id":11901705157,"source_name":"web","fulfillment_status":null,"tax_lines":[{"title":"VAT","price":"62.38","rate":0.125}],"tags":"","contact_email":"kamini_thakur@esferasoft.com","order_status_url":"https:\/\/checkout.shopify.com\/14896240\/checkouts\/5f4411d8cd42c8db5b8d1293c9050ee0\/thank_you_token?key=3d6e6df9bcd4ecd518997fed7eec6fe2","line_items":[{"id":8025627845,"variant_id":20319809861,"title":"Shoes","quantity":1,"price":"499.00","grams":0,"sku":"","variant_title":"","vendor":"maggiedemo","fulfillment_service":"manual","product_id":6210949701,"requires_shipping":true,"taxable":true,"gift_card":false,"name":"Shoes","variant_inventory_management":null,"properties":[],"product_exists":true,"fulfillable_quantity":1,"total_discount":"0.00","fulfillment_status":null,"tax_lines":[{"title":"VAT","price":"62.38","rate":0.125}],"origin_location":{"id":2986131525,"country_code":"IN","province_code":"CH","name":"maggiedemo","address1":"phase5","address2":"","city":"mohali","zip":"160055"},"destination_location":{"id":2991696773,"country_code":"IN","province_code":"CH","name":"dhdhb hfrh","address1":"phase 12","address2":"","city":"mohali","zip":"160055"}}],"shipping_lines":[{"id":3749512005,"title":"Standard Shipping","price":"757.23","code":"ON","source":"Andrew Shipping Service","phone":null,"requested_fulfillment_service_id":null,"delivery_category":null,"carrier_identifier":"ba0f1f8c45cdb9013b310525a5ac81ed","tax_lines":[]}],"billing_address":{"first_name":"dhdhb","address1":"phase 12","phone":null,"city":"mohali","zip":"160055","province":"Chandigarh","country":"India","last_name":"hfrh","address2":"","company":null,"latitude":30.7281,"longitude":76.717665,"name":"dhdhb hfrh","country_code":"IN","province_code":"CH"},"shipping_address":{"first_name":"dhdhb","address1":"phase 12","phone":null,"city":"mohali","zip":"160055","province":"Chandigarh","country":"India","last_name":"hfrh","address2":"","company":null,"latitude":30.7281,"longitude":76.717665,"name":"dhdhb hfrh","country_code":"IN","province_code":"CH"},"fulfillments":[],"client_details":{"browser_ip":"182.71.22.106","accept_language":"en-US,en;q=0.5","user_agent":"Mozilla\/5.0 (X11; Ubuntu; Linux i686; rv:50.0) Gecko\/20100101 Firefox\/50.0","session_hash":"cc137c4988e334cf334511f358e4857c","browser_width":1287,"browser_height":673},"refunds":[],"customer":{"id":4012044165,"email":"kamini_thakur@esferasoft.com","accepts_marketing":false,"created_at":"2016-09-14T02:44:25-04:00","updated_at":"2017-04-05T02:01:55-04:00","first_name":"kamini","last_name":"thakur","orders_count":38,"state":"invited","total_spent":"0.00","last_order_id":4419111109,"note":null,"verified_email":true,"multipass_identifier":null,"tax_exempt":false,"phone":null,"tags":"","last_order_name":"#1042","default_address":{"id":5195499589,"first_name":"dhdhb","last_name":"hfrh","company":null,"address1":"phase 12","address2":"","city":"mohali","province":"Chandigarh","country":"India","zip":"160055","phone":null,"name":"dhdhb hfrh","province_code":"CH","country_code":"IN","country_name":"India","default":true}}}';

$array =json_decode($data);
$tempVar = var_export($array, true);

$fh =fopen('orderCreate.txt', 'w');
//fwrite($fh, $data);

/////// Fetch destination address to create customer job //////////

$address1 = ($array->shipping_address->address1);
$city = ($array->shipping_address->city);
$zip = ($array->shipping_address->zip);
$latitude = ($array->shipping_address->latitude);
$longitude = ($array->shipping_address->longitude);
$dest_contact_name = ($array->shipping_address->first_name);
fwrite($fh,$dest_contact_name);
$dest_contact_phone = ($array->shipping_address->phone);
if(empty($dest_contact_phone))
{
    $dest_contact_phone = 1111111111;
}
fwrite($fh,$dest_contact_phone);
//echo $dest_contact_phone;

fwrite($fh, 'origin');

//////// Get distance and time values from "retrieve shipping file" ////////
if (($handle = fopen('get_distance_time.txt', "r")) !== FALSE)
    {
    	$getData= array();
        if(($getData = fread($handle, filesize("get_distance_time.txt"))) !== FALSE)
        {
        	$getData = json_decode($getData);
        }  
  	fclose($handle);
    }

			$distance = $getData->total->distance;
			$time 	= 	$getData->total->seconds;
			$creditcardID 	= $getData->total->creditcardID;
			$auth_token 	= $getData->total->auth_token;
      $shop_url   = $getData->total->shop_url;
      $shop_token   = $getData->total->shop_token;
			$store_lat 	= $getData->total->pickup_lat;
			$store_lng 	= $getData->total->pickup_lng;
      $Pickup_Address  = $getData->total->Pickup_Address;
      $PickupName  = $getData->total->PickupName;
      $PickupPhone  = $getData->total->PickupNo;
      $notes  = $getData->total->notes;
      $username  = $getData->total->username;
      
			fwrite($fh, $distance);
			fwrite($fh, $time);
			fwrite($fh, $creditcardID);
			fwrite($fh, $auth_token);
      fwrite($fh, $domain);
      fwrite($fh, $shop_token);
      fwrite($fh, $shop_url);

if(empty($PickupPhone))
{
    $PickupPhone = 1111111111;
}
fwrite($fh, $PickupName);
fwrite($fh, $PickupPhone);

////// Request to get the city and zip code of pick-up address ///////

$start_address=urlencode($Pickup_Address);
$Url = 'https://maps.googleapis.com/maps/api/geocode/json?address='.$start_address;
fwrite($fh,$Url);

$getCityZip = json_decode(file_get_contents($Url),true);
fwrite($fh,'testdemo');

echo '<pre>';
print_r($getCityZip);
echo '</pre>';

$key = array_search(array('administrative_area_level_2','political'), array_column($getCityZip['results'][0]['address_components'], 'types'));
$PickupCity=$getCityZip['results'][0]['address_components'][$key]['short_name'];

$key = array_search(array('postal_code'), array_column($getCityZip['results'][0]['address_components'], 'types'));
$PickupZipCode=$getCityZip['results'][0]['address_components'][$key]['short_name'];

// REquest to ITEM-TYPES.JSON to get ITEM_TYPE_ID

$itemTypeAPI = $StagingBaseURL.'item_types.json';
$ch = curl_init();
 
curl_setopt($ch, CURLOPT_URL, $itemTypeAPI);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'X-User-Email: '.$username,
    'X-User-Token: '.$auth_token,
    'Content-Type: application/json'
    ));
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$output=curl_exec($ch);
// echo curl_errno($ch)."-".curl_error($ch);

$result=json_decode($output);

 // echo "<pre>";
 // print_r($result);
 // echo '</pre>';
 //fwrite($fh,$output);
$item_type_id = $result->item_types[0]->id;
//echo $item_type_id;
fwrite($fh, $item_type_id);
curl_close($ch);

$current_time = date("h:i:sa");
//echo $current_time;

$custJob_array[] = array(
  "job" => array(
    "pickup_attributes" => array(
      "coordinates" => array(
        "lat" => $store_lat,
        "lon" => $store_lng
      ),
      "address" => $Pickup_Address,
      "suburb_name" => $PickupCity,
      "postcode" => $PickupZipCode,

      "contact_attributes" => array(
        "name" => $PickupName,
        "phone" => $PickupPhone
      )
    ),
    "dropoff_attributes" => array(
      "coordinates" => array(
        "lat" => $latitude,
        "lon" => $longitude
      ),
      "address" => $address1,
      "suburb_name" => $city,
      "postcode" => $zip,
      "contact_attributes" => array(
        "name" => $dest_contact_name,
        "phone" => $dest_contact_phone
      )
    ),
     "notes" => $notes,
    "credit_card_id" => $creditcardID,
    "total_duration" => $time,
    "total_distance" => $distance,
    "item_type_id" => $item_type_id,
    "deliver_by" => $current_time
  ),
  "distance_based_pricing" => true
);

$custJob_array = json_encode($custJob_array[0]);
fwrite($fh, $custJob_array);

/* Creating customer job request */
$custJoburl = $StagingBaseURL.'my/customer/jobs.json';
fwrite($fh,$custJoburl);
	$ch = curl_init();
	
	curl_setopt($ch, CURLOPT_URL, $custJoburl);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'X-User-Email: '.$username,
    'X-User-Token: '.$auth_token,
    'Content-Type: application/json'
    ));
	curl_setopt($ch,CURLOPT_POSTFIELDS, $custJob_array);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

	$output=curl_exec($ch);
  fwrite($fh,curl_error($ch));
	$result=json_decode($output);
	fwrite($fh,$output);
	//fwrite($fh,$result);

?>