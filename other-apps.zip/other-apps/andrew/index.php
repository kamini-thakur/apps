<?php
header('p3p: CP="ALL DSP COR PSAa PSDa OUR NOR ONL UNI COM NAV"');
ob_start();
session_start();
set_time_limit(0);
ini_set("display_errors", 1);
ini_set('session.gc_maxlifetime', 36000);
session_set_cookie_params(36000);
error_reporting(E_ALL);
require_once 'keys.php';
require_once 'shopify.php';
$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);


$_Company_name    ='';
$_Order_threshold ='';
$_Rate_Abv_Ord   ='';
$_Rate_Blw_Ord    ='';
$shopURL='https://'.$_SESSION['shop'];
$BaseUrl='https://shopify.go-fetch.com.au/andrew/';

try
    {

                
            /* GET /admin/carrier_services/#{id}.json */
                  $shipping_service_request_url='/admin/carrier_services.json';
                  $request_array=$sc->call('GET',$shipping_service_request_url);
                  //var_dump($request_array);
                  $url='/admin/carrier_services.json';
                  $meta=array
                       (
                            "carrier_service"=>array
                            (
                              "name"=> "Andrew Shipping Service",
                              "callback_url"=> $BaseUrl."retrieve_shipping_rate_calc_new_an.php",
                              "format"=> "json",
                              "service_discovery"=> true
                             
                            )
                       );                              
           
                   
                    if(empty($request_array)){
                      $sc->call('POST', $url,$meta);
	                   }

              // create a new order webhook
              $Url='/admin/webhooks.json?address='.$BaseUrl.'new_order.php';
              $getWebhookOrder=$sc->call('GET',$Url);
  
              if(empty($getWebhookOrder))
              {
                   $Url=$BaseUrl."new_order.php";
                   $orderhook = array("webhook"=>array(
                                           "topic"=>"orders/create",
                                           "address"=>$Url,
                                           "format"=>"json"
                                          )
                                  );

                  $orderWeb = $sc->call('POST','/admin/webhooks.json',$orderhook);
              }

             /* call to database to edit values */
              
              $domain=$_SESSION['shop'];
              $shop_token=$_SESSION['token'];

              if(isset($_POST['CreateJob']))
              {
                $username=$_POST['username'];
                $password=$_POST['password'];
                $GoogleApiKey=$_POST['GoogleApiKey'];
                $auth_token=$_POST['auth_token'];
                $Payment_Method=$_POST['PaymentMethod'];
                $Pickup_Address=$_POST['PickupAddress'];
                $Pickup_Contact=$_POST['PickupContact'];
                $notes=$_POST['notes'];

                $sql="SELECT * from shopDetails where shopURL='$domain' ";
                $qex=mysqli_query($con,$sql);
                $num_rows=mysqli_num_rows($qex);
                
                if($num_rows==0)
                {
                  $sql1="INSERT INTO shopDetails(shopURL,shop_token,username,password,GoogleApiKey,auth_token,PaymentMethod,PickupAddress,PickupContact,notes)VALUES('".$domain."','".$shop_token."','".$username."','".$password."','".$GoogleApiKey."','".$auth_token."','".$Payment_Method."','".$Pickup_Address."','".$Pickup_Contact."','".$notes."')";
                  $qex=mysqli_query($con,$sql1);
                  if($qex1)
                  {
                    echo 'Success';
                  }
                  else
                  {
                     echo 'Error';
                  }
                }
                else
                {
                  $sql1="UPDATE shopDetails SET username='$username',password='$password',GoogleApiKey='$GoogleApiKey',auth_token='$auth_token',PaymentMethod='$Payment_Method',PickupAddress='$Pickup_Address',PickupContact='$Pickup_Contact',notes='$notes' WHERE shopURL='$domain' ";
                  $qex1=mysqli_query($con,$sql1);
                  if($qex1)
                  {
                    echo 'Success';
                  }
                  else
                  {
                     echo 'Error';
                  }
                }
                die();
              } 
              

              echo '<div class="wrapperForm">';
              echo '<h3>Dont worry, your shipping rates are been taken care off :)</h3><div class="replace">';

             $sql2="SELECT * from shopDetails where shopURL='$domain' ";
             $qex=mysqli_query($con,$sql2);
             $res=mysqli_fetch_array($qex);
            
              echo '<form id="userForm" method="post" class="form-horizontal" action="">
                      <div class="form-group">
                        <label class="col-sm-3 control-label">Username</label>
                        <div class="col-sm-9">
                        <input type="text" name="username" value="'.$res['username'].'" class="username">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-3 control-label">Password</label>
                        <div class="col-sm-9">
                        <input type="password" name="password" value="'.$res['password'].'" class="password">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                          <input type="submit" name="LogIn" class="btn btn-primary" value="Log in">
                        </div>
                      </div>
                    </form>';

            echo '</div></div>';
    
    }
            catch (ShopifyApiException $e)
    {
    
        // var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
        //  var_dump($e->getPath());// -> path of failing request
        //  var_dump($e->getResponseHeaders());// -> actually response headers from failing request
        //  var_dump();// -> curl response object
         $err=$e->getResponse();
         var_dump($err);
//         echo '<div class="content-error" >
//<p style="color:red">'.$err['errors']['base'][0].'</p></div>'; 
        // var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
    
    }

?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="ie9 no-focus"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-focus"> <!--<![endif]-->
    <head>
       <link rel="stylesheet" href="https://shopify.go-fetch.com.au/andrew/css/style.css">

       <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
       
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

      <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyAMI_SkktNIcuDmiZF_KK3d7_F3FKhOQLM&sansor=false"></script>
  
      <!-- Latest compiled and minified CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

      <!-- Optional theme -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">

      <!-- Latest compiled and minified JavaScript -->
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        </style>
   
    </head>
    <body>
       
        </script>
         <script type="text/javascript">
    ShopifyApp.init({
      apiKey: '<?php echo $api_key; ?>',
      shopOrigin:"<?php echo $shopURL; ?>",

      debug: true
    });
    </script>
   <script type="text/javascript">
  ShopifyApp.ready(function(){
    ShopifyApp.Bar.initialize({
      
      title: 'ADMIN',
      
          
          callback: function(){ 
            ShopifyApp.Bar.loadingOff();
            
          }
       
      
    });
  });
  </script>
  <script type="text/javascript">
      $(document).ready(function(){
       $('form#userForm').on('submit',function(e){
            e.preventDefault();
            console.log('form-submit');
            var username = $('.username').val();
            console.log(username);
            var password = $('.password').val();
            console.log(password);
            //alert(value+btnid);

            $.ajax({
                type:"POST",
                
                url:"custJob.php",
                data: {'Username': username, 'Password': password, 'Domain': '<?php echo $domain ?>'}, 
               success: function (data) {
                  
                 console.log(data);
                 //$('.replace').html(data);

                 var places = new google.maps.places.Autocomplete(document.getElementById('pickupAddress'));
                    google.maps.event.addListener(places, 'place_changed', function () {
                      var place = places.getPlace();
                      console.log('All places'+places);
                      var address = place.formatted_address;
                      var latitude = place.geometry.location.lat();
                      var longitude = place.geometry.location.lng();
                      var mesg = "Address: " + address;
                      mesg += "\nLatitude: " + latitude;
                      mesg += "\nLongitude: " + longitude;

                    });
                } 

          });
        });
      });

      
      </script>
    </body>
</html>