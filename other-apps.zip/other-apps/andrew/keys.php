<?php

$api_key   = "ba0f1f8c45cdb9013b310525a5ac81ed";  // copy from partners account
$secret    = "53dfbfa6e30905c56e95e5c854fc0d8c";  // copy from partners account
//$shop      ='zucue38.myshopify.com'; // Shopify domain in which the APP is being used
//$token     ='f9eab48d5089beb380c9e394ec038979'; // Copy after instaling the APP from the admin

$con=mysqli_connect("localhost","gofetchc_shopify","Sh0pF0rFr33","gofetchc_shopify");
if(mysqli_connect_errno())
{
	echo "connection failed";
}

$StagingBaseURL = 'http://go-fetch.staging.c66.me/api/v1/';
//session_start();

?>