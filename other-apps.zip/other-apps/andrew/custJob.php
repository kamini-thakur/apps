

<?php

require_once 'keys.php';
     
$username=$_POST['Username'];
$password=$_POST['Password'];
$domain=$_POST['Domain'];

$result = SignIn_API($StagingBaseURL,$username,$password);
$name = $result->user->first_name.' '.$result->user->last_name;
$auth_token = $result->user->authentication_token;

$_SESSION['email']=$username;
$_SESSION['name']=$name;


/* Request to fetch contact list */
$Url = $StagingBaseURL.'my/contacts.json';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $Url);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                  'X-User-Email: '.$username,
                  'X-User-Token: '.$auth_token,
                  'Content-Type: application/json'
            ));
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$output=curl_exec($ch);
$ConatctList=json_decode($output);
                   
// echo '<pre>';
// print_r($ConatctList);
// echo '</pre>';
////////////////////////////////////////

$sql2="SELECT * from shopDetails where shopURL='".$domain."' ";
$qex=mysqli_query($con,$sql2);
$res=mysqli_fetch_array($qex);

?>
<select><?php
foreach ($ConatctList->contacts as $key => $value) { ?>
                      <option><?php echo $value->name.' '.$value->phone; ?></option>
      <?php              } ?>
</select>

<h4><b>Logged in as:</b> <span><?php echo $_SESSION['name'] ?></span></h4>
<h4><b>Email:</b> <?php echo $_SESSION['email'] ?></h4>

<a href="logout.php"><button class="btn btn-primary">Sign out</button></a>
<div id="result_msg"></div>
 <form id="CreateCustJob" method="post" class="form-horizontal">
                      <div class="form-group">
                        <label class="col-sm-4 control-label">Google Maps API key<span class="star">*</span></label>
                        <div class="col-sm-8">
                            <input type="text" name="GoogleApiKey" id="GoogleApiKey" class="GoogleApiKey" value="<?php echo $res['GoogleApiKey'] ?>">
                            <input type="hidden" name="username" value="<?php echo $username ?>">
                            <input type="hidden" name="password" value="<?php echo $password ?>">
                            <input type="hidden" name="auth_token" value="<?php echo $auth_token ?>">
                         
                        </div>
                      </div>

                  <div class="form-group">
                        <label class="col-sm-4 control-label">Payment Method<span class="star">*</span></label>
                        <div class="col-sm-8">
                        <select name="PaymentMethod" class="PaymentMethod">
                         	<?php
                         	foreach ($result->credit_cards as $key => $val) { ?>
    	                        	<option value="<?php echo $val->id; ?>"><?php echo '**** **** ****'.$val->last_4_digits; ?></option>
    	                   <?php } ?>
               			  </select>
                        </div>
                  </div>

                   <div class="form-group">
                        <label class="col-sm-4 control-label">Default Pickup Address<span class="star">*</span></label>
                        <div class="col-sm-8">
                        <input type="text" name="PickupAddress" class="pickupAddress" id="pickupAddress" value="<?php echo $res['PickupAddress'] ?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-4 control-label">Default Pickup Contact<span class="star">*</span></label>
                        <div class="col-sm-8">
                        <input type="text" name="PickupContact" class="PickupContact" value="<?php echo $res['PickupContact'] ?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-12 control-label">Additional Notes For Deliveries</label>
                        <div class="col-sm-12">
                        <textarea rows="4" cols="50" name="notes" class="notes"><?php echo $res['notes'] ?></textarea>
                        </div>
                      </div>
                      <input type="hidden" name="CreateJob">
                      <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-9">
                          <input type="submit" name="CreateJob" class="btn btn-primary" value="Save" onclick="return CreateCustJob();">
                        </div>
                      </div>
                    </form>

<?php
			function SignIn_API($StagingBaseURL,$username,$password)
              {
                  $userSignIn = $StagingBaseURL.'users/sign_in.json';
                  $getAuthToken = array( 'user' => array( 'email' => $username, 'password' => $password ));

                   $ch = curl_init();
                   curl_setopt($ch, CURLOPT_URL, $userSignIn);
                   curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-type: multipart/form-data"));
                   curl_setopt($ch,CURLOPT_POSTFIELDS, http_build_query($getAuthToken));
                   curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

                   $output=curl_exec($ch);
                   $result=json_decode($output); 
                   return $result;
             }
?>

<script type="text/javascript">
  function CreateCustJob() {
          var GoogleApiKey = $('.GoogleApiKey').val();
          var PaymentMethod = $('.PaymentMethod').val();
          var pickupAddress = $('.pickupAddress').val();
          var PickupContact = $('.PickupContact').val();
          var notes = $('.notes').val();
         
       if( GoogleApiKey== '' || PaymentMethod== '' || pickupAddress== '' || PickupContact== '' || notes== '' )
       {
           $("#result_msg").html("Please fill out all the mandatory fields");
           $("#result_msg").addClass('error-message');
           return false;
       }
       else
       {
          var formData =  $.post('index.php', $('#CreateCustJob').serialize())  .done(function( data ) {
          if(data == 'Success')
          {
            $("#result_msg").html("Value Saved");
            $("#result_msg").addClass('confirmation');
          }
          else
          {
            $("#result_msg").html("Error Occured");
            $("#result_msg").addClass('error-message');
          }
         });
        return false;
       }
       
}
</script>


