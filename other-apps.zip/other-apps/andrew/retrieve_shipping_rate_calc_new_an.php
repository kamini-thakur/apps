<?php
require 'keys.php';
header('Content-Type:application/json');
$data =file_get_contents('php://input');
$array =json_decode($data);
$fh =fopen('retrieve_shipping.txt', 'w');
$domain = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
fwrite($fh,$data);
// Fetch database values
$sql2="SELECT * from shopDetails where shopURL='$domain' ";
$qex=mysqli_query($con,$sql2);
$res=mysqli_fetch_array($qex);

function calculate($url)
{
	$ch = curl_init();
	//fwrite($fh,$url);

	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

	$output=curl_exec($ch);
	$result=json_decode($output);
	return $result;
}

// Destination address
$country = ($array->rate->destination->country);
$province = ($array->rate->destination->province);
$city = ($array->rate->destination->city);
$address1 = ($array->rate->destination->address1);
$pincode = ($array->rate->destination->postal_code);

$dest_address = $address1.'+'.$city.'+'.$province.'+'.$country.'+'.$pincode;
$dest_address = str_replace(' ', '',$dest_address);

$googleApi = $res['GoogleApiKey'];
//fwrite($fh,$googleApi);
$username = $res['username'];
$Pickup_Address = $res['PickupAddress'];
$PickupContact = $res['PickupContact'];
$notes = $res['notes'];
$creditcardID = $res['PaymentMethod'];
$auth_token = $res['auth_token'];
$shop_token = $res['shop_token'];
fwrite($fh,$username);
fwrite($fh,$creditcardID);
fwrite($fh,$Pickup_Address);
fwrite($fh,$PickupContact);

// Source address

$Pickup_Address = str_replace(' ', '',$Pickup_Address);
$source_address = str_replace(',', '+',$Pickup_Address);
fwrite($fh,$source_address);
preg_match('/[^\d]+/', $PickupContact, $textMatch);
preg_match('/\d+/', $PickupContact, $numMatch);

$PickupName = $textMatch[0];
$PickupNo = $numMatch[0];
fwrite($fh,$PickupName);
fwrite($fh,$PickupNo);
fwrite($fh,'pickup contact');
/*
$country = ($array->rate->origin->country);
$province = ($array->rate->origin->province);
$city = ($array->rate->origin->city);
$address1 = ($array->rate->origin->address1);
$pincode = ($array->rate->origin->postal_code);

$source_address = $address1.'+'.$city.'+'.$province.'+'.$country.'+'.$pincode;
$source_address = str_replace(' ', '',$source_address);
*/

// Request to calculate distance between source and destination

$url= 'https://maps.googleapis.com/maps/api/directions/json?origin='.$source_address.'&destination='.$dest_address.'&key='.$googleApi;
fwrite($fh,$url);
$cal_distance=calculate($url);
fwrite($fh,json_encode($cal_distance));
$distance = ($cal_distance->routes[0]->legs[0]->distance->value);
$seconds = ($cal_distance->routes[0]->legs[0]->duration->value);
$pickup_lat = ($cal_distance->routes[0]->legs[0]->start_location->lat);
$pickup_lng = ($cal_distance->routes[0]->legs[0]->start_location->lng);
$start_address = ($cal_distance->routes[0]->legs[0]->start_address);

// Request to calculate price based on distance between source and destination

$calUrl= 'https://go-fetch.com.au/api/v1/jobs/calculate.json?distance_meters='.$distance.'&seconds='.$seconds;
fwrite($fh,$calUrl);
$cal_price=calculate($calUrl);
//fwrite($fh,$cal_price);
$price = ($cal_price->price_cents);
//fwrite($fh,$price);

fclose($fh);

/* create another file for saving distance and time */
$distanceTxt =fopen('get_distance_time.txt', 'w');
$calValues = array('total'=> array('distance' => $distance, 'seconds' => $seconds , 'creditcardID' => $creditcardID ,'auth_token' => $auth_token,'shop_url' =>  $domain, 'shop_token' => $shop_token, 'pickup_lat' => $pickup_lat, 'pickup_lng' => $pickup_lng, 'username' => $username, 'Pickup_Address' => $start_address, 'PickupName' => $PickupName, 'PickupNo' => $PickupNo, 'notes' => $notes));
fwrite($distanceTxt,json_encode($calValues));

		        	$rates_array[]=array(
		                                 'service_name'     =>  'Standard Shipping',
		                                 'service_code'     =>  'ON',
		                                 'total_price'      =>  $price,
		                                 'currency'         =>  'AUD',
		                                 'min_delivery_date'=>'0000-00-00 00:00:00 -0000',
                                     	'max_delivery_date'=>'0000-00-00 00:00:00 -0000'
		                                 );
                 
				  $return_array=array(
				             "rates"=>$rates_array
				                 );
				  echo json_encode($return_array);


?>

   <ul>
          {% for link in linklists.top-right-menu.links %}
        
        	{% assign child_list_handle = link.title | handle %}
       
        		{% if linklists[child_list_handle] and linklists[child_list_handle].links.size > 0 %}

        		<li><a class="h_a_link hasSubmenu" href="{{ link.url }}" value="{{ link.handle }}">{{ link.title }}</a></li>
         	    <ul style="display:none;" class="hasDropdown">
                  {% for child_link in linklists[child_list_handle].links %}
                  <li><a href= "{{ child_link.url }}">{{ child_link.title }}</a></li>
                  {% endfor %}
    			</ul>
        		{% else %}
        			<a class="h_a_link" href="{{ link.url }}" value="{{ link.handle }}">{{ link.title }}</a>
        		{% endif %}
         
          {% endfor %}
      </ul>



      =================================================

      <?php 

require_once 'header.php';
require 'keys.php';
require 'shopify.php';
require 'database_config.php';

$Array= array();

$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);

try
        {

        date_default_timezone_set("Europe/Berlin");
        $t=time();
        $date=(date("Y-m-d",$t));
        $currentTime=(date("h:i:sa",$t));

        $_DOMAIN = $_SESSION['shop'];
        
        $request = $sc->call('GET','/admin/orders.json');
        //global $currentProdID='';
        //echo '/admin/orders.json?updated_at_min='.$date;

		if($_SESSION['shop'] == 'fashioncirclede.myshopify.com')
		{
			// echo '<pre>';
			// print_r($request);
			// echo '</pre>';
		}
        
		$shopCurrency = ($sc->call('GET', '/admin/shop.json?fields=money_format'));
		$money_format= $shopCurrency['money_format'];
		$symbol = explode("{{", $money_format);

		$vendor = array();
		
		foreach ($request as $key => $val) {
       		 
       		foreach ($val['line_items'] as $key => $value) {

		            if( isset($value['product_id']) ) {
					$value['product_id'];
		            	  // $vendor['orderName']=$val['name'];
		            	  // $vendor['orderId']=$val['id'];
		            	 $GetMeta = $sc->call('GET','/admin/products/'.$value['product_id'].'/metafields.json?namespace=FCProdPrice');
		            	 if(!empty($GetMeta))
		            	 {
		            	 	 $key = array_search('FCProdPrice', array_column($GetMeta, 'namespace'));
			            	 $prodPrice=$GetMeta[$key]['value'];
			            	
			            	 $vendor_name =str_replace('Fashioncircle-', '', $value['vendor']); 
				              if (array_key_exists($vendor_name,$vendor))
							  {
							  		$vendor[$vendor_name] +=  ($prodPrice)*($value['quantity']);
							  }
							else
							  {
							  		$vendor[$vendor_name] =  ($prodPrice)*($value['quantity']);
							  }  
		            	 }
		            	  
					} 
			}
       }
// echo '<pre>';
// 		print_r($vendor);
// 		echo '</pre>';
       echo '<center><h4>Total amount to be paid to each vendor</h4></center><br><br>';

       echo '<div class="loading-dots" id="loading-dots">
				<center>
				<div class="loaderDots">Loading...</div>
				</center>
			</div>';
       echo '<form id="payOrder" action="paypalPayment.php" method="post" onsubmit="window.location.reload();">';
	   echo '<table class="table table-hover"><tr><th>Filter</th><th>Vendor Name</th><th>Total price</th></tr>';

		foreach($vendor as $key => $val)
		{
			$amount = round($val,2);
			$response = insertPaymentDetails($key,$amount);
			if($response == 'Success')
			{
				$sql = "SELECT * from paymentDetails where shopDomain='$_DOMAIN' and vendorName = '$key' ";
				$qex = mysqli_query($newCon,$sql);
				$res = mysqli_fetch_array($qex);
				if ($res['paymentStatus'] == 'pending') {

					echo '<tr><td><input type="checkbox" name="receiver_data[]" value="'.$res['vendorId'].'"></td>
					<td>'.$res['vendorName'].'</td><td>'.$symbol[0].$res['amount'].'</td></tr>';	
				}
			}
			else
			{
				echo 'Error occured';
			}
	    }
		echo '</table>';
		echo '<input class="btn btn-warning payWithPaypal" type="submit" name="sendPayment" value="Pay with paypal">';
		echo '</form>';
		
		
}
catch (ShopifyApiException $e)
    {
		
         var_dump($e->getMethod());// -> http method (GET, POST, PUT, DELETE)
         var_dump($e->getPath());// -> path of failing request
         var_dump($e->getResponseHeaders());// -> actually response headers from failing request
         var_dump($e->getResponse());// -> curl response object
         var_dump($e->getParams());// -> optional data that may have been passed that caused the failure
		
    }


function insertPaymentDetails($vendorName,$amount)
{
		global $newCon,$_DOMAIN;
		$sql = "SELECT * from paymentDetails where shopDomain='$_DOMAIN' and vendorName = '$vendorName' ";
		$qex = mysqli_query($newCon,$sql);
		$res = mysqli_fetch_array($qex);
		//$pendingAmount = $res['amount'];
		$num_rows = mysqli_num_rows($qex);

		if($num_rows == 0)
		{
			//echo 'inside if';
			$get_last_id = "SELECT id from paymentDetails order by id DESC limit 0,1" ;
			$exe_query = mysqli_query($newCon,$get_last_id);
			$result = mysqli_fetch_array($exe_query);
			if(isset($result['id']))
			{
				$vendorId = '#10'.$result['id'];
			}
			else
			{
				$vendorId = '#10';
			}
			$transactionTrackingId = 'id_'.$vendorId;
			
			$insertNewVendor="INSERT INTO paymentDetails(shopDomain,vendorName,vendorId,vendorEmail,amount,paymentStatus,transactionTrackingId) VALUES('".$_DOMAIN."','".$vendorName."','".$vendorId."','kamini_thakur-buyer@esferasoft.com','".$amount."','pending','".$transactionTrackingId."')";
     		$qex=mysqli_query($newCon,$insertNewVendor); 

		}
		else
		{
			$updateVendor="UPDATE paymentDetails set amount='$amount' where shopDomain='$_DOMAIN' and vendorName='$vendorName' ";
     		$qex=mysqli_query($newCon,$updateVendor);
		}
		if($qex)
		{
			return 'Success';
		}
		else
		{
			return 'Error';
		}
}

?>
<script type="text/javascript">
	$('form#payOrder').submit(function(e){
		window.location.reload();
		$('#loading-dots').show();
		setTimeout(function(){ $('#loading-dots').hide(); }, 4000);
		
	});
</script>