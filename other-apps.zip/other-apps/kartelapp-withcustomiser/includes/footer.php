</div>
<div class="copyright">Copyright &copy; <?php echo date('Y', time())?> - esferasoft.com </div>
</div>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

</body>
</html>