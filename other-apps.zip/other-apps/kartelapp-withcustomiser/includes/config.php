<?php


$shopify_domain ='kartel-time.myshopify.com';
$api_key = 'c755b9d728a248787aff0beaefba3f3d';
$api_password = '93fbb82e9f22512d0df09a8308c0d574'; 

// $varId40mm = 32461062414;
// $varId34mm = 32461046734;

$varId40mm = 451087564814;
$varId34mm = 451087728654;

$strap_collectionId = '451829774';
$case_collectionId = '451827982';

$url = generateURL($shopify_domain,$api_key,$api_password); 




