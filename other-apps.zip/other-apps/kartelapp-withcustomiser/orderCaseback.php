<?php


$data =file_get_contents('php://input');
$array =json_decode($data);
$tempVar = var_export($array, true);

$fh =fopen('orderCreate.txt', 'w');
fwrite($fh, $data);

$count40mm=0; $count34mm=0;
foreach($array->line_items as $key=>$val)
{
	$title=$val->title;
	if( strpos( $title, '40mm' ) !== false ) {
	   	if($array->line_items[$key+1]->title == 'Engraving')
		{
			$var_id=$val->variant_id;
			$count40mm++;
		}
	}
	if( strpos( $title, '34mm' ) !== false ) {
    	if($array->line_items[$key+1]->title == 'Engraving')
		{
			$var_id=$val->variant_id;
			$count34mm++;
		}
	}
	
}

fwrite($fh, $count40mm);
fwrite($fh, $count34mm);


/* Code to update strap and case inventory for customiser goes here */
$strap_exist=0; $case_exist=0;
foreach($array->line_items as $key=>$val)
{
	$customiser_title=$val->title;
	if (strpos($customiser_title, 'Build Your') !== false ) {
		foreach ($val->properties as $key => $propValues) {
			$property_name = $propValues->name;
			$property_value = $propValues->value;

			if (strpos($property_value, 'KT-CASE') !== false) {
				$case_sku = $property_value;
				$case_exist++;
			}
			if (strpos($property_name, 'Strap') !== false) {
				$strap_sku = $propValues->value;
				if (strpos($strap_sku, ' (') !== false) {
					$strap_sku = explode("(",$strap_sku);
					// echo 'strap_sku'.$strap_sku[0];
					$strap_sku = trim($strap_sku[0]);
				}
				$strap_exist++;
			}
		}
	}
}

fwrite($fh, 'strap_sku'.$strap_sku);
fwrite($fh, 'case_sku'.$case_sku);

fwrite($fh, 'strap_exist='.$strap_exist);
fwrite($fh, 'case_exist='.$case_exist);

include('index.php');

?>