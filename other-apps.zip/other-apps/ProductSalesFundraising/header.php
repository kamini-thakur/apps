<?php
header('p3p: CP="ALL DSP COR PSAa PSDa OUR NOR ONL UNI COM NAV"');
ob_start();
session_start();
set_time_limit(0);
// ini_set("display_errors", 1);
ini_set('session.gc_maxlifetime', 36000);
session_set_cookie_params(36000);
// error_reporting(E_ALL);

///////////// Get token from database /////////
// $sql="SELECT * from shopDetails where shopDomain='$_DOMAIN' ";
// $qex=mysqli_query($newCon,$sql);
// $res = mysqli_fetch_array($qex);
// $Exec_status = $res['Exec_status'];
// $Final_status = $res['Final_status'];


?>
<html>
<head>
  <title>SHOPIFY APP</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">


  <!-- <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

      <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">

      <!-- Latest compiled and minified JavaScript -->
  
  <link rel="stylesheet" href="css/style.css" />
 

  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js" async="true">></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" async="true">></script>
   <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
<script>

$(document).ready(function(){

 $('.SaveCollection').on('click',function(e){
  e.preventDefault();
  var CollectionTitle=$( ".selectCollection option:selected" ).val();
  var colId=$( ".selectCollection option:selected" ).attr('data-collection');

  setTimeout(function(){ $('.successMsg').css('display','block'); }, 3000);
  setTimeout(function(){ $('.successMsg').hide(); }, 7000);
 
  $.ajax({
              url:"index.php",
              type:"POST",
              data: { collectionId : colId, CollectionTitle: CollectionTitle  },
                  
              success: function(response){
                  console.log('success');
                  $('.successMsg').css('display','block');
                  //setTimeout(function(){ $('.successMsg').hide(); }, 5000);
              }
  });
  });
});
</script>

<script type="text/javascript">
    ShopifyApp.init({
      apiKey: '<?php echo $api_key; ?>',
      shopOrigin:"<?php echo $shopURL; ?>",

      debug: true
    });
</script>
<script type="text/javascript">
  ShopifyApp.ready(function(){
    ShopifyApp.Bar.initialize({
      
      title: 'Fashion Circle',
          callback: function(){ 
            ShopifyApp.Bar.loadingOff();
            
          }
    });
  });
  </script>  
</head>
