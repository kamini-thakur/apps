<?php

set_time_limit(0);
require 'keys.php';
require 'shopify.php';
require 'database_config.php';

$sql="SELECT * from shopDetails where Exec_status=0 and Final_status=0 order by id ASC limit 0,1";
$qex=mysqli_query($newCon,$sql);

$fh       =fopen('productSales.txt', 'w')  or fwrite($fh,"Utyftyftf");

while($res=mysqli_fetch_assoc($qex))
{
    $id = $res['id'];

    $update_exec_status="UPDATE shopDetails set Exec_status='1' where id='".$id."' ";
    $qex=mysqli_query($newCon,$update_exec_status);

    $shopDomain = $res['shopDomain'];
    $shopToken = $res['shopToken'];
    $sc= new ShopifyClient($shopDomain, $shopToken, $api_key, $secret);
	//////// Get count of total orders //////////

	$total_orders = $sc->call('GET', '/admin/orders/count.json?status=closed');
	$order_per_page = 250; 
	$total_pages = ceil($total_orders / $order_per_page); 

	$products = array();

	////////////// Get all paid orders of a shop /////////
	for ($cur_page=1; $cur_page <= $total_pages; ++$cur_page) { 
	  
	    $orders = $sc->call('GET', '/admin/orders.json?status=closed&limit='.$order_per_page.'&page='.$cur_page); 
	  
	    foreach ($orders as $order)
	    {
	      foreach ($order['line_items'] as $key => $value) {
	          if( !empty($value['product_id']) ) {
	                  
	                if (array_key_exists($value['product_id'],$products))
	                {
	                      $products[$value['product_id']] +=  ($value['price'])*($value['quantity']);
	                }
	                else
	                {
	                      $products[$value['product_id']] =  ($value['price'])*($value['quantity']);
	                }            
	          } /// End if 
	      } ////  End foreach for product variants
	    } //// End of orders
	} /// End of total store orders

	// echo "<pre>";
 //    print_r($products);
 //    echo "</pre>";

	fwrite($fh, print_r($products,true));

	//////////////////// Create /update metafields of the products ////////////
	foreach($products as $key => $val)
	{
	    $product_id = $key;
	    $price = $val;
	   	$GetMeta = $sc->call('GET','/admin/products/'.$product_id.'/metafields.json?namespace=Fundraising');
	    
	    if(empty($GetMeta))
	    {
	            $meta = array("metafield"=>array(
	              "namespace"=>"Fundraising",
	              "key"=>"sales",
	              "value"=>$price,
	              "value_type"=>"string"
	              )
	            );
	            $AddMetafield=$sc->call('POST','/admin/products/'.$product_id.'/metafields.json',$meta);
	    }

	    sleep(1);
	}

	$update_final_status="UPDATE shopDetails set Final_status='1' where id='".$id."' ";
    $qex=mysqli_query($newCon,$update_final_status);
    return "success";
}  

?>