
<?php

require_once '../header.php';
require_once '../shopify.php';
require_once '../keys.php';
require_once '../database_config.php';

$data     =(file_get_contents('php://input'));

// echo 'hi';

//$data='{"id":212830724,"order_id":5808265220,"created_at":"2017-07-14T01:50:57-04:00","note":"","restock":true,"user_id":122445444,"processed_at":"2017-07-14T01:50:57-04:00","refund_line_items":[{"id":171600964,"quantity":1,"line_item_id":11509037188,"subtotal":699.0,"total_tax":125.82,"line_item":{"id":11509037188,"variant_id":44595629316,"title":"black-sleepers","quantity":2,"price":"699.00","grams":0,"sku":"","variant_title":"","vendor":"kamini@esfera","fulfillment_service":"manual","product_id":11358414340,"requires_shipping":true,"taxable":true,"gift_card":false,"name":"black-sleepers","variant_inventory_management":"shopify","properties":[],"product_exists":true,"fulfillable_quantity":0,"total_discount":"0.00","fulfillment_status":"fulfilled","tax_lines":[{"title":"GST","price":"251.64","rate":0.18}],"origin_location":{"id":3191633092,"country_code":"IN","province_code":"PB","name":"ProductSalesFundraising","address1":"SCF 20 , Phase 2","address2":"","city":"Mohali","zip":"160055"},"destination_location":{"id":3194120452,"country_code":"IN","province_code":"CH","name":"kamini dvd","address1":"vdeeg","address2":"","city":"grgv","zip":"160055"}}},{"id":171601028,"quantity":1,"line_item_id":11509037252,"subtotal":499.0,"total_tax":89.82,"line_item":{"id":11509037252,"variant_id":44595641028,"title":"Black shoes","quantity":1,"price":"499.00","grams":0,"sku":"","variant_title":"","vendor":"kamini@esfera","fulfillment_service":"manual","product_id":11358416516,"requires_shipping":true,"taxable":true,"gift_card":false,"name":"Black shoes","variant_inventory_management":"shopify","properties":[],"product_exists":true,"fulfillable_quantity":0,"total_discount":"0.00","fulfillment_status":"fulfilled","tax_lines":[{"title":"GST","price":"89.82","rate":0.18}],"origin_location":{"id":3191633092,"country_code":"IN","province_code":"PB","name":"ProductSalesFundraising","address1":"SCF 20 , Phase 2","address2":"","city":"Mohali","zip":"160055"},"destination_location":{"id":3194120452,"country_code":"IN","province_code":"CH","name":"kamini dvd","address1":"vdeeg","address2":"","city":"grgv","zip":"160055"}}}],"transactions":[{"id":6480095620,"order_id":5808265220,"amount":"1413.64","kind":"refund","gateway":"Cash on Delivery (COD)","status":"success","message":"Refunded 1413.64 from manual gateway","created_at":"2017-07-14T01:50:57-04:00","test":false,"authorization":null,"currency":"INR","location_id":null,"user_id":null,"parent_id":6466868356,"device_id":null,"receipt":{},"error_code":null,"source_name":"web"}],"order_adjustments":[]}';

$fh       =fopen('orderRefund.txt', 'w')  or die("Utyftyftf");
fwrite($fh, $data);

/* GET DOMAIN FROM HEDAERS  */
$_HEADERS = apache_request_headers();
$_DOMAIN  =$_HEADERS['X-Shopify-Shop-Domain'];
// echo 'domain'.$_DOMAIN = $_SESSION['shop'];
fwrite($fh, $_DOMAIN);

///////////// Get token from database /////////
$sql="SELECT * from shopDetails where shopDomain='$_DOMAIN' ";
$qex=mysqli_query($newCon,$sql);
$res = mysqli_fetch_array($qex);

$shopToken = $res['shopToken'];
fwrite($fh,$shopToken);

$sc = new ShopifyClient($_DOMAIN, $shopToken, $api_key, $secret);

$array    =json_decode($data);
// echo '<pre>';
// print_r($array);
// echo '</pre>';

foreach ($array->refund_line_items as $key => $value) {

	//print_r($value);
	$prod_id=$value->line_item->product_id;
	fwrite($fh,'product id'.$prod_id);
	$price=$value->subtotal;
	fwrite($fh,'price'.$price);
	$quantity =$value->quantity;
	fwrite($fh,'quantity'.$quantity);


	if (!empty($prod_id)) {
        $GetMeta = $sc->call('GET','/admin/products/'.$prod_id.'/metafields.json?namespace=Fundraising');
        //print_r($GetMeta);
      
            $key = array_search('Fundraising', array_column($GetMeta, 'namespace'));
            $metafield_id=$GetMeta[$key]['id']; 
            $prevProdPrice=$GetMeta[$key]['value']; 
            echo 'old price value'.$prevProdPrice;
            // $newPrice=  ($price)*($quantity);

            $price = ($prevProdPrice)-($price);
            echo 'updated price value'.$price;

            $meta = array("metafield"=>array(
                          "id"=>$metafield_id,
                          "value"=>$price,
                          "value_type"=>"string"
                          )
            );
            //print_r($meta);
          
            $updateMetafield=$sc->call('PUT','/admin/products/'.$prod_id.'/metafields/'.$metafield_id.'.json',$meta);  
         
	}

}

?>