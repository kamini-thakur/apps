
<?php

// header("Content-Security-Policy: default-src '*'");
// header("Access-Control-Allow-Origin: *");
error_reporting(E_ALL);
ini_set("display_errors", 1);

require 'database_config.php';
require_once 'header.php';
require 'keys.php';
require 'shopify.php';

if(!$_SESSION['shop'])
{
   header('Location: login.php');
}

$sc = new ShopifyClient($_SESSION['shop'], $_SESSION['token'], $api_key, $secret);

$_DOMAIN=$_SESSION['shop'];
$baseURL = 'https://esoftappslive.com';

//////////Create order update Webhook as well as check it///////////

$url ='/admin/webhooks.json';

$orderUpdateArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/ProductSalesFundraising/webhooks/orderUpdated.php');
$meta=array
(
    "webhook"=>array 
    (
       "topic"=> "orders/updated",
       "address"=> $baseURL."/ProductSalesFundraising/webhooks/orderUpdated.php",
        "format"=>"json"
    )
);
  
if (empty($orderUpdateArray)) {           
    $sc->call('POST', $url,$meta);
}

//////////// Create app order fulfilled webhook ////////////

$OrderFulfilledArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/ProductSalesFundraising/webhooks/orderFulfilled.php');
$meta=array
(
    "webhook"=>array 
    (
       "topic"=> "orders/fulfilled",
       "address"=> $baseURL."/ProductSalesFundraising/webhooks/orderFulfilled.php",
        "format"=>"json"
    )
);
  
if (empty($OrderFulfilledArray)) {           
    $sc->call('POST', $url,$meta);
}

//////////// Create app refunds/create webhook ////////////

// $OrderRefundArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/ProductSalesFundraising/webhooks/orderRefund.php');
// $meta=array
// (
//     "webhook"=>array 
//     (
//        "topic"=> "refunds/create",
//        "address"=> $baseURL."/ProductSalesFundraising/webhooks/orderRefund.php",
//         "format"=>"json"
//     )
// );
  
// if (empty($OrderRefundArray)) {           
//     $sc->call('POST', $url,$meta);
// }

//////////// Create app uninstallation webhook ////////////

$uninstallArray=$sc->call('GET','/admin/webhooks.json?address='.$baseURL.'/ProductSalesFundraising/webhooks/uninstall.php');
      $uninstallMeta=array
      (
                    "webhook"=>array 
                    (
                     "topic"=> "app/uninstalled",
                     "address"=> $baseURL."/ProductSalesFundraising/webhooks/uninstall.php",
                     "format"=>"json"
                    )
      );
    

      if (empty($uninstallArray))
      {     
          $sc->call('POST', $url,$uninstallMeta);
      }       

//////////////// Save MVP access token in database//////////////////
$shopDomain = $_SESSION['shop'];
$shopToken = $_SESSION['token'];

if(isset($_SESSION['shop']))
{ 
  $sql="SELECT * from shopDetails where shopDomain='$shopDomain' ";
  $qex=mysqli_query($newCon,$sql);
  $res=mysqli_fetch_array($qex);
  $Exec_status=$res['Exec_status'];
  $Final_status=$res['Final_status'];

  $num_rows=mysqli_num_rows($qex);
  
  if($num_rows==0)
  { 
    $sql="INSERT INTO shopDetails(shopDomain,shopToken,Exec_status,Final_status)VALUES('".$shopDomain."','".$shopToken."',0,0)";
    $qex=mysqli_query($newCon,$sql); 
  }
  else
  {
    $sql="UPDATE shopDetails set shopToken='".$shopToken."' where shopDomain='".$shopDomain."' ";
    $qex=mysqli_query($newCon,$sql);
  }
  if ($qex) {
    // echo "Success";
  }
  else
  {
    // echo "error";
  }
  
}

echo "<body>";

if ($Exec_status!=1 and $Final_status!=1 ) 
{
  echo "<div class='outer-form alert-info'>";
  echo "<h4>We're currently configuring the total sales of the products on your store. This should take less than 15 minutes. If you'd like, you can close this and continue working.</h4>";
  echo "</div>";
}
 

if ($Exec_status==1 and $Final_status==1 ) 
{
    echo "<div class='outer-form'>";
    $collections = $sc->call('GET', '/admin/custom_collections.json');
    
    echo "<h3>Select collection:</h3>";

    $GetMetafieldColl = $sc->call('GET','/admin/metafields.json?namespace=SelectedCollection');
    if (!empty($GetMetafieldColl)) {
      $key = array_search('SelectedCollection', array_column($GetMetafieldColl, 'namespace'));
      $SelectedCollection=$GetMetafieldColl[$key]['value'];
      $metafield_ID=$GetMetafieldColl[$key]['id']; 
    }

    echo "<select id='selectCollection' class='selectCollection' name='selectedCollection' >";
    foreach($collections as $key=>$v)
    {
      if( $v['title'] ==  $SelectedCollection ){ 
        $ShowSelected = 'selected="selected"'; 
      }
      else
      {
        $ShowSelected ='';
      }
      echo "<option value='".$v['title']."' data-collection='".$v['id']."' $ShowSelected>".$v['title']."</option>";
    }
    echo "</select>";
    echo "<input type='submit' name='saveColl' id='SaveCollection' class='SaveCollection' value='Save'/>";
    echo "<div class='successMsg' style='display:none;'>Collection saved successfully</div>";

    echo "</div>";
}


if(isset($_POST['collectionId']))
{
  //echo 'get';
  $collId = $_POST['collectionId'];
  $collTitle = $_POST['CollectionTitle'];

  $GetCollectionMeta = $sc->call('GET','/admin/metafields.json?namespace=SelectedCollection');

  $collection_meta = array("metafield"=>array(
                          "namespace"=>"SelectedCollection",
                          "key"=>"Fundraise",
                          "value"=>$collTitle,
                          "value_type"=>"string"
                          )
                    );

  if(empty($GetCollectionMeta))
  {
      ///// Create new metafield //////////
      $create_shop_metafield = $sc->call('POST','/admin/metafields.json',$collection_meta);
  }
  else
  {
      $update_collection_meta = array("metafield"=>array(
                          "id"=>$metafield_ID,
                          "value"=>$collTitle,
                          "value_type"=>"string"
                          )
                    );
      ///// Update existing metafield ////////
      $update_shop_metafield = $sc->call('PUT','/admin/metafields/'.$metafield_ID.'.json',$update_collection_meta);
  }
}
///////////////////////////////////////////

////////////// Delete all products metafields /////////////////
/*
$total_products = $sc->call('GET', '/admin/products/count.json');
$product_per_page = 250; 
$total_pages = ceil($total_products / $product_per_page); 

echo "<table border='1'>";
for ($cur_page=1; $cur_page <= $total_pages; ++$cur_page) { 
  $getProducts= $sc->call('GET','/admin/products.json?limit='.$product_per_page.'&page='.$cur_page);
   // echo "<pre>";
   //    print_r($getProducts);
   //    echo "</pre>";
    $count=1;
    foreach($getProducts as $key => $value)
    {
        echo "<tr><td>".$count."</td>";
        $product_id = $value['id'];
        echo "<td>".$product_id."</td></tr>";
        $getProdMetafields = $sc->call('GET','/admin/products/'.$product_id.'/metafields.json?namespace=Fundraising');
       
        if (!empty($getProdMetafields)) {
         
           $key = array_search('Fundraising', array_column($getProdMetafields, 'namespace'));
     
                     $metafieldId = $getProdMetafields[$key]['id'];
                    $sc->call('DELETE','/admin/products/'.$product_id.'/metafields/'.$metafieldId.'.json'); 
           
        }
        else
        {
          echo "in else".$count;
        }

        echo "<pre>";
        print_r($getProdMetafields);
        echo "</pre>";

       // sleep(1);

        ++$count;
    //echo "first loop stop";
      }
}
echo "</table>";
*/
?>



</body>
</html>
