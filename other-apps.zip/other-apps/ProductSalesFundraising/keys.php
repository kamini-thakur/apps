<?php

$api_key = "93663e4da88c43ad42347673df1415c6";
$secret = "4cfb9a981bb30fefd4f0466b49d7d651";

//$token = 'd900133dbae8bbd38fd4ce0a2dca92a3';

?>