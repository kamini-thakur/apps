<?php

$_HOST     = 'localhost';
$_USER_NAME= 'root';
$_PASSWORD = 'amardeep';
$_DATABASE = 'SalesFundraising';
$newCon=mysqli_connect($_HOST, $_USER_NAME,$_PASSWORD,$_DATABASE);
if(mysqli_connect_errno())
{
	echo "connection failed";
}

?>